//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include "stdafx.h"
#include "catch.hpp"
#include "lib.h"

namespace ManagedTestProject {

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR
    static void foo1();
    namespace{
        [TestClass]
        public ref class cls1
        {
        private:
	        TestContext^ testContextInstance;
        public:
	        property Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ TestContext
	        {
		        Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ get()
		        {
			        return testContextInstance;
		        }
		        System::Void set(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ value)
		        {
			        testContextInstance = value;
		        }
	        };
        public:
            [TestMethod]
            [Description( "Example without macros" )]
            [TestProperty( "Description", "Example without macros" )]
            void registered_test()
            {
                Catch::ConfigData cd;
                cd.name = "foo1";
                Catch::Ptr<Catch::Config> config(new Catch::Config(cd));
                Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get());
                Catch::RunContext tr(config.get(), rep);
                Catch::NameAndDesc nd( "foo1", "tag" );
                Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( &foo1 ), "", nd.name, nd.description, CATCH_INTERNAL_LINEINFO );
                tr.runTest(tc); 
            }
        };
    }
    void foo1()
    {
        REQUIRE(false);
    }
#else
    static void foo1();
    TEST_CLASS(cls1)
    {
    public:
	    BEGIN_TEST_METHOD_ATTRIBUTE(registered_test)
            TEST_OWNER(L"foo1")
            TEST_DESCRIPTION(L"Example without macros")
	    END_TEST_METHOD_ATTRIBUTE()
    	TEST_METHOD(registered_test)
        {
            Catch::ConfigData cd;
            cd.name = "foo1";
            Catch::Ptr<Catch::Config> config(new Catch::Config(cd));
            Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get());
            Catch::RunContext tr(config.get(), rep);
            Catch::NameAndDesc nd( "foo1", "tag" );
            Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( &foo1 ), "", nd.name, nd.description, CATCH_INTERNAL_LINEINFO );
            tr.runTest(tc); 
        }
    };
    void foo1()
    {
        REQUIRE(false);
    }
#endif

    class StaticTest {
    public:
        static void run() {
            REQUIRE(false);
        }
    };

    class UniqueTestsFixture {
    private:
        static int uniqueID;
    public:
        UniqueTestsFixture() { }
    protected:
        int getID() {
            return ++uniqueID;
        }
    };

    int UniqueTestsFixture::uniqueID = 0;

    TEST_CASE( CATCH_WIDEN("Catch test case using MS Test"), "")
    {
        REQUIRE(false);
    }

    METHOD_AS_TEST_CASE(StaticTest::run,CATCH_WIDEN("Static method as test case"), "");

    TEST_CASE_METHOD(UniqueTestsFixture, CATCH_WIDEN("Catch test case method"), "[create]")
    {
        REQUIRE(getID() == 1);
    }
} // namespace 
