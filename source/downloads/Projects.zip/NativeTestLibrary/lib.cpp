//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#include "lib.h"
#include <stdexcept>

NativeTestClass::NativeTestClass(std::string n, int v)
    : m_name(n), m_value(v)
{}

std::string NativeTestClass::getName() const
{
    return m_name;
}

void NativeTestClass::changeName(const std::string& n)
{
    m_name = n;
}

int NativeTestClass::getValue() const
{
    if( m_name == "Fred" )
    {
        return m_value;
    }
    throw std::runtime_error("Should be Fred");
}
