import os
import sys

catchPath = os.path.dirname(os.path.realpath( os.path.dirname(sys.argv[0])))