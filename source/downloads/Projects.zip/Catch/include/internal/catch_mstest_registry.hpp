/*
 *  Created by Malcolm on 6/11/2013.
 *  Copyright 2013 Malcolm Noyes. All rights reserved.
 *
 *  Distributed under the Boost Software License, Version 1.0. (See accompanying
 *  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */
#ifndef TWOBLUECUBES_CATCH_MSTEST_REGISTRY_HPP_INCLUDED
#define TWOBLUECUBES_CATCH_MSTEST_REGISTRY_HPP_INCLUDED

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wweak-vtables"
#endif

#include "catch_common.h"
#include "catch_interfaces_testcase.h"
#include "internal/catch_compiler_capabilities.h"
//#include "catch_config.hpp"

namespace Catch {

    typedef void(*TestFunction)();

    class FreeFunctionTestCase : public SharedImpl<ITestCase> {
    public:

        FreeFunctionTestCase( TestFunction fun ) : m_fun( fun ) {}

        virtual void invoke() const {
            m_fun();
        }

    private:
        virtual ~FreeFunctionTestCase();

        TestFunction m_fun;
    };

    std::string translateActiveException() {
        try {
#ifdef __OBJC__
            // In Objective-C try objective-c exceptions first
            @try {
                throw;
            }
            @catch (NSException *exception) {
                return toString( [exception description] );
            }
#else
            throw;
#endif
        }
        catch( std::exception& ex ) {
            return ex.what();
        }
        catch( std::string& msg ) {
            return msg;
        }
        catch( const char* msg ) {
            return msg;
        }
        catch(...) {
            return "Unknown exception";
        }
    }

template<typename C>
class MethodTestCase : public SharedImpl<ITestCase> {

public:
    MethodTestCase( void (C::*method)() ) : m_method( method ) {}

    void invoke() const {
        C obj;
        (obj.*m_method)();
    }

private:
    virtual ~MethodTestCase() {}

    void (C::*m_method)();
};

typedef void(*TestFunction)();

struct NameAndDesc {
    NameAndDesc( const char* _name = "", const char* _description= "" )
    : name( _name ), description( _description )
    {}
    NameAndDesc( const char* _name, int )
    : name( _name ), description( "" )
    {}
#if !defined(_MANAGED) && !defined(_M_CEE) // detect CLR
    NameAndDesc( const wchar_t* _name, const char* _description= ""  )
    : name(), description( _description )
    {
        stdext::cvt::wstring_convert<std::codecvt_utf8<wchar_t> > conv1;
        name = conv1.to_bytes(_name);
    }
#endif

    std::string name;
    std::string description;
};

} // end namespace Catch

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR
#define CATCH_WIDEN( x ) x
#else
#ifdef _UNICODE
#define CATCH_WIDEN( x )    L ## x
#else
#define CATCH_WIDEN( x ) x
#endif
#endif

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR
#define INTERNAL_CATCH_CLASS_DEFINITION( cls ) \
            [TestClass] \
            public ref class cls

#define INTERNAL_CATCH_CLASS_CONTEXT \
        private: \
	        TestContext^ testContextInstance; \
        public: \
	        property Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ TestContext \
	        { \
		        Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ get() \
		        { \
			        return testContextInstance; \
		        } \
		        System::Void set(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ value) \
		        { \
			        testContextInstance = value; \
		        } \
	        };

#else
#define INTERNAL_CATCH_CLASS_DEFINITION( cls ) \
            TEST_CLASS( cls )

#define INTERNAL_CATCH_CLASS_CONTEXT

#endif
//#undef CATCH_CONFIG_VARIADIC_MACROS

#ifdef CATCH_CONFIG_VARIADIC_MACROS

    #define INTERNAL_CATCH_SPLIT_ARGS_2( ... ) INTERNAL_CATCH_SPLIT_ARGS_IMPL_2((__VA_ARGS__, 2,1))
    #define INTERNAL_CATCH_SPLIT_ARGS_IMPL_2(tuple) INTERNAL_CATCH_SPLIT_ARGS_IMPL2 tuple
    #define INTERNAL_CATCH_SPLIT_ARGS_IMPL2(INTERNAL_CATCH_SPLIT_ARG_1,INTERNAL_CATCH_SPLIT_ARG_2,N,...) INTERNAL_CATCH_SPLIT_ARG_1
    #define INTERNAL_CATCH_SPLIT_TAGS( ... ) INTERNAL_CATCH_SPLIT_TAGS_IMPL((__VA_ARGS__, 2,1))
    #define INTERNAL_CATCH_SPLIT_TAGS_IMPL(tuple) INTERNAL_CATCH_SPLIT_TAGS_IMPL_ tuple
    #define INTERNAL_CATCH_SPLIT_TAGS_IMPL_(INTERNAL_CATCH_SPLIT_ARG_1,INTERNAL_CATCH_SPLIT_ARG_2,N,...) INTERNAL_CATCH_SPLIT_ARG_2

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR
#define INTERNAL_CATCH_TEST_METHOD( Method, ... ) \
        public: \
            [TestMethod] \
            [Description( INTERNAL_CATCH_SPLIT_ARGS_2( __VA_ARGS__ ) )] \
            [TestProperty( "Description", INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__) )] \
            void registered_test() \
            { \
                Catch::ConfigData cd; \
                Catch::NameAndDesc name_desc( INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__), INTERNAL_CATCH_SPLIT_TAGS(__VA_ARGS__) ); \
                cd.name = name_desc.name; \
                Catch::Ptr<Catch::Config> config(new Catch::Config(cd)); \
                Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get()); \
                Catch::RunContext tr(config.get(), rep); \
                Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( & Method ), "", name_desc.name, name_desc.description, CATCH_INTERNAL_LINEINFO ); \
                tr.runTest(tc); \
            }

#else
#define INTERNAL_CATCH_TEST_METHOD( Method, ... ) \
        public: \
	    BEGIN_TEST_METHOD_ATTRIBUTE(registered_test) \
            TEST_OWNER( INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__) ) \
            TEST_DESCRIPTION( INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__) ) \
	    END_TEST_METHOD_ATTRIBUTE() \
    	TEST_METHOD(registered_test) \
        { \
            Catch::ConfigData cd; \
            Catch::NameAndDesc name_desc( INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__), INTERNAL_CATCH_SPLIT_TAGS(__VA_ARGS__) ); \
            cd.name = name_desc.name; \
            Catch::Ptr<Catch::Config> config(new Catch::Config(cd)); \
            Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get()); \
            Catch::RunContext tr(config.get(), rep); \
            Catch::NameAndDesc nd( INTERNAL_CATCH_SPLIT_ARGS_2(__VA_ARGS__), INTERNAL_CATCH_SPLIT_TAGS(__VA_ARGS__) ); \
            Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( & Method ), "", name_desc.name, name_desc.description, CATCH_INTERNAL_LINEINFO ); \
            tr.runTest(tc); \
        }

#endif
    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_TESTCASE( ... ) \
        static void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )(); \
        INTERNAL_CATCH_CLASS_DEFINITION( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
            INTERNAL_CATCH_TEST_METHOD( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ), __VA_ARGS__ ) \
        }; \
        void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )()

    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_METHOD_AS_TEST_CASE( QualifiedMethod, ... ) \
        INTERNAL_CATCH_CLASS_DEFINITION(INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
            INTERNAL_CATCH_TEST_METHOD( QualifiedMethod, __VA_ARGS__ ) \
        };

    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_TEST_CASE_METHOD( ClassName, ... )\
        struct INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ) : ClassName { \
            void test(); \
            static void invoke() {INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ) tmp; tmp.test(); } \
        }; \
        INTERNAL_CATCH_CLASS_DEFINITION( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
            INTERNAL_CATCH_TEST_METHOD( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )::invoke, __VA_ARGS__ ) \
        }; \
        void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )::test()

#else
    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_TESTCASE( Name, Desc ) \
        static void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )(); \
        INTERNAL_CATCH_CLASS_DEFINITION( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
        public: \
            [TestMethod] \
            [Description( Name )] \
            [TestProperty( "Description", Name )] \
            void registered_test() \
            { \
                Catch::ConfigData cd; \
                cd.name = Name; \
                Catch::Ptr<Catch::Config> config(new Catch::Config(cd)); \
                Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get()); \
                Catch::RunContext tr(config.get(), rep); \
                Catch::NameAndDesc nd( Name, Desc ); \
                Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( &INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ) ), "", nd.name, nd.description, CATCH_INTERNAL_LINEINFO ); \
                tr.runTest(tc); \
            } \
        }; \
        void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )()

    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_METHOD_AS_TEST_CASE( QualifiedMethod, Name, Desc ) \
        INTERNAL_CATCH_CLASS_DEFINITION( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
        public: \
            [TestMethod] \
            [Description( Name )] \
            [TestProperty( "Description", Name )] \
            void registered_test() \
            { \
                Catch::ConfigData cd; \
                cd.name = Name; \
                Catch::Ptr<Catch::Config> config(new Catch::Config(cd)); \
                Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get()); \
                Catch::RunContext tr(config.get(), rep); \
                Catch::NameAndDesc nd( Name, Desc ); \
                Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( &QualifiedMethod ), "", nd.name, nd.description, CATCH_INTERNAL_LINEINFO ); \
                tr.runTest(tc); \
            } \
        };

    ///////////////////////////////////////////////////////////////////////////////
    #define INTERNAL_CATCH_TEST_CASE_METHOD( ClassName, TestName, Desc )\
        struct INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ) : ClassName { \
            void test(); \
            static void invoke() {INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ ) tmp; tmp.test(); } \
        }; \
        INTERNAL_CATCH_CLASS_DEFINITION( INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____C_L_A_S_S____ ) ) \
        { \
            INTERNAL_CATCH_CLASS_CONTEXT \
        public: \
            [TestMethod] \
            [Description( TestName )] \
            [TestProperty( "Description", TestName )] \
            void registered_test() \
            { \
                Catch::ConfigData cd; \
                cd.name = TestName; \
                Catch::Ptr<Catch::Config> config(new Catch::Config(cd)); \
                Catch::MSTestReporter* rep = new Catch::MSTestReporter(config.get()); \
                Catch::RunContext tr(config.get(), rep); \
                Catch::NameAndDesc nd( TestName, Desc ); \
                Catch::TestCase tc = Catch::makeTestCase( new Catch::FreeFunctionTestCase( &INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )::invoke ), #ClassName, nd.name, nd.description, CATCH_INTERNAL_LINEINFO ); \
                tr.runTest(tc); \
            } \
        }; \
        void INTERNAL_CATCH_UNIQUE_NAME( ____C_A_T_C_H____T_E_S_T____ )::test()

#endif

#include "catch_test_case_info.hpp"
#include "catch_assertionresult.hpp"
#include "catch_expressionresult_builder.hpp"
#include "catch_version.hpp"
#include "catch_text.h"
#include "catch_text.hpp"
#include "catch_runner_impl.hpp"
#include "catch_message.hpp"
#include "catch_context_impl.hpp"
#include "catch_generators_impl.hpp"
#include "catch_test_case_info.hpp"

namespace Catch {
    NonCopyable::~NonCopyable() {}
    IShared::~IShared() {}
    StreamBufBase::~StreamBufBase() throw() {}
    IContext::~IContext() {}
    IResultCapture::~IResultCapture() {}
    ITestCase::~ITestCase() {}
    ITestCaseRegistry::~ITestCaseRegistry() {}
    //IRegistryHub::~IRegistryHub() {}
    IMutableRegistryHub::~IMutableRegistryHub() {}
    IExceptionTranslator::~IExceptionTranslator() {}
    IExceptionTranslatorRegistry::~IExceptionTranslatorRegistry() {}
    IReporter::~IReporter() {}
    IReporterFactory::~IReporterFactory() {}
    IReporterRegistry::~IReporterRegistry() {}
    IStreamingReporter::~IStreamingReporter() {}
    AssertionStats::~AssertionStats() {}
    SectionStats::~SectionStats() {}
    TestCaseStats::~TestCaseStats() {}
    TestGroupStats::~TestGroupStats() {}
    TestRunStats::~TestRunStats() {}
    //CumulativeReporterBase::SectionNode::~SectionNode() {}
    //CumulativeReporterBase::~CumulativeReporterBase() {}

    //StreamingReporterBase::~StreamingReporterBase() {}
    //ConsoleReporter::~ConsoleReporter() {}
    IRunner::~IRunner() {}
    IMutableContext::~IMutableContext() {}
    IConfig::~IConfig() {}
    //XmlReporter::~XmlReporter() {}
    //JunitReporter::~JunitReporter() {}
    //TestRegistry::~TestRegistry() {}
    FreeFunctionTestCase::~FreeFunctionTestCase() {}
    IGeneratorInfo::~IGeneratorInfo() {}
    IGeneratorsForTest::~IGeneratorsForTest() {}
    TagParser::~TagParser() {}
    TagExtracter::~TagExtracter() {}
    TagExpressionParser::~TagExpressionParser() {}

    Matchers::Impl::StdString::Equals::~Equals() {}
    Matchers::Impl::StdString::Contains::~Contains() {}
    Matchers::Impl::StdString::StartsWith::~StartsWith() {}
    Matchers::Impl::StdString::EndsWith::~EndsWith() {}

    void Config::dummy() {}

    //INTERNAL_CATCH_REGISTER_LEGACY_REPORTER( "xml", XmlReporter )
}

#ifdef __clang__
#pragma clang diagnostic pop
#endif

#endif // TWOBLUECUBES_CATCH_MSTEST_REGISTRY_HPP_INCLUDED
