//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

//
// This example demonstrates compile time implementation of FizzBuzz without using Boost.MPL.
//
// Following the example of Adam Petersen (http://www.adampetersen.se/articles/fizzbuzz.htm)
//

#include <iostream>
#include <typeinfo>

struct void_;

template <int N>
struct int_
{
    static const int value = N;
};

template <class XT0 = void_, class XT1 = void_, class XT2 = void_, class XT3 = void_,
    class XT4 = void_, class XT5 = void_, class XT6 = void_, class XT7 = void_,
    class XT8 = void_, class XT9 = void_, class XT10 = void_, class XT11 = void_,
    class XT12 = void_, class XT13 = void_, class XT14 = void_, class XT15 = void_> 
struct vector
{
    typedef vector type;
    typedef XT0 T0;
    typedef XT1 T1;
    typedef XT2 T2;
    typedef XT3 T3;
    typedef XT4 T4;
    typedef XT5 T5;
    typedef XT6 T6;
    typedef XT7 T7;
    typedef XT8 T8;
    typedef XT9 T9;
    typedef XT10 T10;
    typedef XT11 T11;
    typedef XT12 T12;
    typedef XT13 T13;
    typedef XT14 T14;
    typedef XT15 T15;
};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10, class T11,
    class T12, class T13, class T14, class T15>
struct size_impl : int_<16> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10, class T11,
    class T12, class T13, class T14>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11,T12,T13,T14,void_> : int_<15> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10, class T11,
    class T12, class T13>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11,T12,T13,void_,void_> : int_<14> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10, class T11,
    class T12>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11,T12,void_,void_,void_> : int_<13> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10, class T11>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11,void_,void_,void_,void_> : int_<12> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9, class T10>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,void_,void_,void_,void_,void_> : int_<11> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8, class T9>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,void_,void_,void_,void_,void_,void_> : int_<10> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7,
    class T8>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,T8,void_,void_,void_,void_,void_,void_,void_> : int_<9> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6, class T7>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,T7,void_,void_,void_,void_,void_,void_,void_,void_> : int_<8> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5, class T6>
struct size_impl<T0,T1,T2,T3,T4,T5,T6,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<7> {};

template <class T0, class T1, class T2, class T3,
    class T4, class T5>
struct size_impl<T0,T1,T2,T3,T4,T5,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<6> {};

template <class T0, class T1, class T2, class T3,
    class T4>
struct size_impl<T0,T1,T2,T3,T4,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<5> {};

template <class T0, class T1, class T2, class T3>
struct size_impl<T0,T1,T2,T3,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<4> {};

template <class T0, class T1, class T2>
struct size_impl<T0,T1,T2,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<3> {};

template <class T0, class T1>
struct size_impl<T0,T1,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<2> {};

template <class T0>
struct size_impl<T0,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<1> {};

template <>
struct size_impl<void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_,void_> : int_<0> {};

template <class Sequence>
struct size : size_impl<typename Sequence::T0, typename Sequence::T1, typename  Sequence::T2, typename  Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename  Sequence::T6, typename  Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename  Sequence::T10, typename  Sequence::T11,
    typename Sequence::T12, typename Sequence::T13, typename  Sequence::T14, typename  Sequence::T15>
{};

template <class Sequence, class T, int N>
struct push_back_impl;

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 0>
    : vector<T, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 1>
    : vector<typename Sequence::T0, T, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 2>
    : vector<typename Sequence::T0, typename Sequence::T1, T, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 3>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, T, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 4>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3, T,
    void_, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 5>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, T, void_, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 6>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, T, void_, void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 7>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, T,
    void_, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 8>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    T, void_, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 9>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, T, void_, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 10>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, T, void_, void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 11>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename Sequence::T10, T,
    void_, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 12>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename Sequence::T10, typename Sequence::T11,
    T, void_, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 13>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename Sequence::T10, typename Sequence::T11,
    typename Sequence::T12, T, void_, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 14>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename Sequence::T10, typename Sequence::T11,
    typename Sequence::T12, typename Sequence::T13, T, void_>
{};

template <class Sequence, class T>
struct push_back_impl<Sequence, T, 15>
    : vector<typename Sequence::T0, typename Sequence::T1, typename Sequence::T2, typename Sequence::T3,
    typename Sequence::T4, typename Sequence::T5, typename Sequence::T6, typename Sequence::T7,
    typename Sequence::T8, typename Sequence::T9, typename Sequence::T10, typename Sequence::T11,
    typename Sequence::T12, typename Sequence::T13, typename Sequence::T14, T>
{};

template <class Sequence, class T>
struct push_back
    : push_back_impl<Sequence, T, size<Sequence>::value >
{};

template <class T1, class T2, bool c>
struct if_c_impl
{
    typedef T1 type;
};

template <class T1, class T2>
struct if_c_impl<T1, T2, false>
{
    typedef T2 type;
};

template<bool c, class T1, class T2>
struct if_c : if_c_impl<T1,T2,c>
{};

struct Fizz{};
struct Buzz{};
struct FizzBuzz{};

template<int i>
struct RunFizzBuzz
{
    typedef int_<i> Number;
    typedef typename if_c<i % 3 == 0, Fizz, Number>::type condition1;
    typedef typename if_c<(i % 5 == 0), Buzz, condition1>::type condition2;
    typedef typename if_c<(i % 3 == 0) && (i % 5 == 0), FizzBuzz, condition2>::type condition3;
    typedef typename push_back<typename RunFizzBuzz<i - 1>::type, condition3>::type type;
};

template<>
struct RunFizzBuzz<0>
{
    typedef vector<int_<0> > type;
};

int main()
{
    //typedef RunFizzBuzz<20>::ret::compilation_error_here res;
    //typedef RunFizzBuzz<1>::ret::compilation_error_here res;
    //typedef z<v<v<v<int_x<0>,int_x<1> >,int_x<2> >,int_x<3> > >::ret::compilation_error_here res;
    //typedef cons<int>::type T1;
    //typedef cons<long>::type T2;
    //typedef cons<int_x<1>, typename cons<int_x<2> >::type::head>::type type;
    //typedef cons<int_x<0>, typename type::head, typename type::tail> T3;
    //T3 t;
//typedef vector<int_<0>,int_<1>,int_<2> >::compilation_error_here res;
    //typedef cons<int_x<0>, typename type::head, typename type::tail>::ret res;
    //typedef GenLinearHierarchy<TypeList<int_x<2>, TypeList<int_x<1>, null_type > >, vx>::ret::compilation_error_here res;
    std::cout << size<vector<int_<0>,int_<1>,int_<2> > >::value << std::endl;
    std::cout << size<vector<int_<0>,int_<1> > >::value << std::endl;
    std::cout << size<vector<int_<0> > >::value << std::endl;
    std::cout << size<vector<> >::value << std::endl;
    typedef vector<int_<0> > T;
    std::cout << size<T>::value << std::endl;
    std::cout << "Type: " << typeid(T).name() << std::endl;
    typedef push_back<T, int_<1> > TX;
    std::cout << "Type: " << typeid(TX::type).name() << std::endl;
    typedef if_c<int_<1>::value % 3 == 0,Fizz,int_<1> > TC;
    std::cout << "Type: " << typeid(TC::type).name() << std::endl;
    typedef if_c<int_<3>::value % 3 == 0,Fizz,int_<3> > TC1;
    std::cout << "Type: " << typeid(TC1::type).name() << std::endl;
    typedef RunFizzBuzz<15>::type::compilation_error_here res;
} 
