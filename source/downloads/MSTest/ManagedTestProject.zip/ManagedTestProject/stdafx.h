// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR

#else
#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#endif
