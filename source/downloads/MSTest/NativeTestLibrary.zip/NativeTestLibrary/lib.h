//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef NATIVE_LIB_H
#define NATIVE_LIB_H

#include <string>

class NativeTestClass
{
public:
    NativeTestClass(std::string n, int v);
    std::string getName() const;
    int getValue() const;
    void changeName(const std::string& n);
private:
    std::string m_name;
    int m_value;
};

#endif // NATIVE_LIB_H
