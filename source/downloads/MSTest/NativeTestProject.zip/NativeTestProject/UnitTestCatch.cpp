//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include "stdafx.h"
#include "MSManagedTestMacros.hpp"

#include "lib.h"

namespace ManagedTestProject {

    TEST_CLASS(TestWithoutInitializeAndCleanup)
    {
        MS_TEST_CASE_METHOD(Method1)
        {
            NativeTestClass* m_data = new NativeTestClass("Fred", 42);
            REQUIRE(m_data != NULL);
            std::string result = m_data->getName();
            REQUIRE(result == "Fred");
        }

        MS_TEST_CASE_METHOD(Method2)
        {
            NativeTestClass* m_data = new NativeTestClass("Fred", 42);
            REQUIRE(m_data != NULL);
            std::string result = m_data->getName();
            REQUIRE(result != "Fred");
        }
    };

    TEST_CLASS(TestWithInitializeAndCleanup)
    {
        NativeTestClass* m_data;

        TEST_METHOD_INITIALIZE(MyInitialize)
        {
            m_data = new NativeTestClass("Fred", 42);
        }
		
        TEST_METHOD_CLEANUP(MyCleanup)
        {
            delete m_data;
            m_data = NULL;
        }

        MS_TEST_CASE_METHOD(Method1)
        {
            REQUIRE(m_data != NULL);
            std::string result = m_data->getName();
            REQUIRE(result == "Fred");
        }

        MS_TEST_CASE_METHOD(Method2)
        {
            REQUIRE(m_data != NULL);
            std::string result = m_data->getName();
            REQUIRE(result != "Fred");
        }
    };

} // namespace 
