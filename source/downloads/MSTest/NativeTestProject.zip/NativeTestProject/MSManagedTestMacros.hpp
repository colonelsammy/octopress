//          Copyright Malcolm Noyes 2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef MS__TEST_MACROS_H
#define MS__TEST_MACROS_H

#if (_MANAGED == 1) || (_M_CEE == 1) // detect CLR

#define REQUIRE(x) Assert::IsTrue(x)
#define FAIL(x) Assert::Fail(x)
using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;
using namespace Microsoft::VisualStudio::TestTools::UnitTesting;

#define TEST_CLASS(cls) \
    [TestClass] \
    public ref class cls

#define TEST_CLASS_CONTEXT() \
    private: \
	    TestContext^ testContextInstance; \
    public: \
	    property Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ TestContext \
	    { \
		    Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ get() \
		    { \
			    return testContextInstance; \
		    } \
		    System::Void set(Microsoft::VisualStudio::TestTools::UnitTesting::TestContext^ value) \
		    { \
			    testContextInstance = value; \
		    } \
	    }; \
    private:

#define MS_TEST_CASE_METHOD(name) \
public: \
[TestMethod] \
    void name ()

#define TEST_METHOD_INITIALIZE(methodName) \
    public: \
    [TestInitialize()] \
    void methodName(void)

#define TEST_METHOD_CLEANUP(methodName) \
    public: \
    [TestCleanup()] \
    void methodName(void)

#else

#ifdef _WINDLL

#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

#define MS_TEST_CASE_METHOD(name) TEST_METHOD(name)
#define REQUIRE(x) Assert::IsTrue(x)
#define FAIL(x) Assert::Fail(x)

#else // _WINDLL

#include "catch.hpp"

#define TEST_CLASS(cls) \
namespace ns_##cls \
{ \
    template <typename T> \
    void setup(T t) { } \
    template <typename T> \
    void cleanup(T t) { } \
    static const std::string test_class_name = std::string( #cls );\
} \
namespace ns_##cls

#define TEST_CLASS_CONTEXT()

#define TEST_METHOD_INITIALIZE(methodName) \
    void setup(int)

#define TEST_METHOD_CLEANUP(methodName) \
    void cleanup(int)

#define MS_TEST_CASE_METHOD(name) \
    namespace setup_and_teardown_##name { \
    static const std::string test_case_name = test_class_name + "::" + #name;\
    struct st_name \
    { \
        st_name () \
        { \
            setup(0); \
        } \
        virtual ~ st_name () \
        { \
            cleanup(0); \
        } \
    }; \
    } \
    TEST_CASE_METHOD( setup_and_teardown_##name :: st_name , setup_and_teardown_##name :: test_case_name.c_str() )

#endif // _WINDLL

#endif

#endif // MS__TEST_MACROS_H
