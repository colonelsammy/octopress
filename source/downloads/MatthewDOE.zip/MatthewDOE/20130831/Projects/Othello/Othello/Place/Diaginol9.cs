﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {
        public List<int> diaginol9(int player, int place, int coloumn, List<int> checka, List<int> tochange)
        {
            if (player == 1)
            {
                if ((place + 63 < (coloumn + 7) * 8) && (place + 63 < 64))
                {
                    if ((checka[place + 63] == 1) && (checka[place + 54] == 2) && (checka[place + 45] == 2)
                        && (checka[place + 36] == 2) && (checka[place + 27] == 2) && (checka[place + 18] == 2) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 6;
                    }
                }

                if ((place + 54 < (coloumn + 6) * 8) && (place + 54 < 64))
                {
                    if ((checka[place + 54] == 1) && (checka[place + 45] == 2) && (checka[place + 36] == 2)
                                && (checka[place + 27] == 2) && (checka[place + 18] == 2) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 5;
                    }
                }

                if ((place + 45 < (coloumn + 5) * 8) && (place + 45 < 64))
                {
                    if ((checka[place + 45] == 1) && (checka[place + 36] == 2)
                       && (checka[place + 27] == 2) && (checka[place + 18] == 2) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 4;
                    }
                }

                if ((place + 36 < (coloumn + 4) * 8) && (place + 36 < 64))
                {
                    if ((checka[place + 36] == 1) && (checka[place + 27] == 2) && (checka[place + 18] == 2) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 3;
                    }
                }

                if ((place + 27 < (coloumn + 3) * 8) && (place + 27 < 64))
                {
                    if ((checka[place + 27] == 1) && (checka[place + 18] == 2) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 2;
                    }
                }

                if ((place + 18 < (coloumn + 2) * 8) && (place + 18 < 64))
                {
                    if ((checka[place + 18] == 1) && (checka[place + 9] == 2))
                    {
                        tochange[6] = 1;
                    }
                }



                if ((place - 63 >= (coloumn - 7) * 8) && (place - 63 > 0))
                {
                    if ((checka[place - 63] == 1) && (checka[place - 54] == 2) && (checka[place - 45] == 2)
                        && (checka[place - 36] == 2) && (checka[place - 27] == 2) && (checka[place - 18] == 2) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 6;
                    }
                }

                if ((place - 54 >= (coloumn - 6) * 8) && (place - 54 > 0))
                {
                    if ((checka[place - 54] == 1) && (checka[place - 45] == 2) && (checka[place - 36] == 2)
                                && (checka[place - 27] == 2) && (checka[place - 18] == 2) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 5;
                    }
                }

                if ((place - 45 >= (coloumn - 5) * 8) && (place - 45 > 0))
                {
                    if ((checka[place - 45] == 1) && (checka[place - 36] == 2)
                       && (checka[place - 27] == 2) && (checka[place - 18] == 2) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 4;
                    }
                }

                if ((place - 36 >= (coloumn - 4) * 8) && (place - 36 > 0))
                {
                    if ((checka[place - 36] == 1) && (checka[place - 27] == 2) && (checka[place - 18] == 2) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 3;
                    }
                }

                if ((place - 27 >= (coloumn - 3) * 8) && (place - 27 > 0))
                {
                    if ((checka[place - 27] == 1) && (checka[place - 18] == 2) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 2;
                    }
                }

                if ((place - 18 >= (coloumn - 2) * 8) && (place - 18 > 0))
                {
                    if ((checka[place - 18] == 1) && (checka[place - 9] == 2))
                    {
                        tochange[7] = 1;
                    }
                }
            }
            else
            {
                if ((place + 63 < (coloumn + 7) * 8) && (place + 63 < 64))
                {
                    if ((checka[place + 63] == 2) && (checka[place + 54] == 1) && (checka[place + 45] == 1)
                        && (checka[place + 36] == 1) && (checka[place + 27] == 1) && (checka[place + 18] == 1) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 6;
                    }
                }

                if ((place + 54 < (coloumn + 6) * 8) && (place + 54 < 64))
                {
                    if ((checka[place + 54] == 2) && (checka[place + 45] == 1) && (checka[place + 36] == 1)
                                && (checka[place + 27] == 1) && (checka[place + 18] == 1) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 5;
                    }
                }

                if ((place + 45 < (coloumn + 5) * 8) && (place + 45 < 64))
                {
                    if ((checka[place + 45] == 2) && (checka[place + 36] == 1)
                       && (checka[place + 27] == 1) && (checka[place + 18] == 1) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 4;
                    }
                }

                if ((place + 36 < (coloumn + 4) * 8) && (place + 36 < 64))
                {
                    if ((checka[place + 36] == 2) && (checka[place + 27] == 1) && (checka[place + 18] == 1) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 3;
                    }
                }

                if ((place + 27 < (coloumn + 3) * 8) && (place + 27 < 64))
                {
                    if ((checka[place + 27] == 2) && (checka[place + 18] == 1) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 2;
                    }
                }

                if ((place + 18 < (coloumn + 2) * 8) && (place + 18 < 64))
                {
                    if ((checka[place + 18] == 2) && (checka[place + 9] == 1))
                    {
                        tochange[6] = 1;
                    }
                }



                if ((place - 63 >= (coloumn - 7) * 8) && (place - 63 > 0))
                {
                    if ((checka[place - 63] == 2) && (checka[place - 54] == 1) && (checka[place - 45] == 1)
                        && (checka[place - 36] == 1) && (checka[place - 27] == 1) && (checka[place - 18] == 1) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 6;
                    }
                }

                if ((place - 54 >= (coloumn - 6) * 8) && (place - 54 > 0))
                {
                    if ((checka[place - 54] == 2) && (checka[place - 45] == 1) && (checka[place - 36] == 1)
                                && (checka[place - 27] == 1) && (checka[place - 18] == 1) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 5;
                    }
                }

                if ((place - 45 >= (coloumn - 5) * 8) && (place - 45 > 0))
                {
                    if ((checka[place - 45] == 2) && (checka[place - 36] == 1)
                       && (checka[place - 27] == 1) && (checka[place - 18] == 1) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 4;
                    }
                }

                if ((place - 36 >= (coloumn - 4) * 8) && (place - 36 > 0))
                {
                    if ((checka[place - 36] == 2) && (checka[place - 27] == 1) && (checka[place - 18] == 1) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 3;
                    }
                }

                if ((place - 27 >= (coloumn - 3) * 8) && (place - 27 > 0))
                {
                    if ((checka[place - 27] == 2) && (checka[place - 18] == 1) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 2;
                    }
                }

                if ((place - 18 >= (coloumn - 2) * 8) && (place - 18 > 0))
                {
                    if ((checka[place - 18] == 2) && (checka[place - 9] == 1))
                    {
                        tochange[7] = 1;
                    }
                }
            }

            return tochange;
        }
    }
}