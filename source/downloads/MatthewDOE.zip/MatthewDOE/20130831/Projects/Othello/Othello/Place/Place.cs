﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {

        // 0 is player, 1 is place, 2 is right, 3 is left, 4 is up, 5 is down
        // 6 is +9, 7 is -9

        public List<int> turnpiece(int player, int place, int coloumn, List<int>checka)
        {
            List<int> tochange = new List<int>();
            for (int x = 0; x < 10; x = x + 1)
            {
                tochange.Add(0);
            }
            tochange = sides(player, place, checka, tochange);
            tochange = updown(player, place, coloumn, checka, tochange);
            tochange = diaginol7(player, place, coloumn, checka, tochange);
            tochange = diaginol9(player, place, coloumn, checka, tochange);
            tochange[0] = player;
            tochange[1] = place;
            return tochange;
        }
    }
}
