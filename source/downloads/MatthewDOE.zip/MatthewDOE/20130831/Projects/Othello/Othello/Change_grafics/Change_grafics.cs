﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        public void change(int player, List<int> change)
        
       {
            access = change;

            if ((Ai.on == false) || (playerturn == 1) || (Ai.turn == true))
            {
                if (((access[2] == 0) && (access[3] == 0) && (access[4] == 0)
                && (access[5] == 0) && (access[6] == 0) && (access[7] == 0)
                && (access[8] == 0) && (access[9] == 0)) || countershown[access[1]] > 0)
                {
                    MessageBox.Show("You can't go there");

                    black[access[1]].Picture.Hide();
                    
                    if (countershown[access[1]] == 1)
                    {
                        black[access[1]].Picture.Show();
                        black[access[1]].Picture.Image = Othello.Properties.Resources.black;
                    }
                    else if (countershown[access[1]] == 2)
                    {
                        black[access[1]].Picture.Show();
                        black[access[1]].Picture.Image = Othello.Properties.Resources.white;
                    }
                    
                }
                else
                {
                    if (access[0] == 1)
                    {
                        countershown[access[1]] = 1;
                        black[access[1]].Picture.Show();
                    }
                    else
                    {
                        countershown[access[1]] = 2;
                        black[access[1]].Picture.Show();
                        black[access[1]].Picture.Image = Othello.Properties.Resources.white;
                    }
                    Change(access[1]);
                    
                    
                    end_turn();
                    if ((Ai.on == true) && (playerturn == 2))
                    {
                        Ai.turn = true;
                        Aitimer.Start();
                    }

                }
            }
            
        }

        private void number()
        {
            bnumber = 0;
            wnumber = 0;
            for (int x = 0; x < 64; x = x + 1)
            {
                if (countershown[x] == 1)
                {
                    bnumber = bnumber + 1;
                }
                if (countershown[x] == 2)
                {
                    wnumber = wnumber + 1;
                }
            }
            player1count.Items.Clear();
            player1count.Items.Add(bnumber);
            player2count.Items.Clear();
            player2count.Items.Add(wnumber);
        }

        private void Change(int place)
        {
            for (int i = 1; i <= access[2]; i++)
            {
                turnover(place + i * 8);
                countershown[place + i * 8] = access[0];
            }
            for (int i = 1; i <= access[3]; i++)
            {
                turnover(place - i * 8);
                countershown[place - i * 8] = access[0];
            }

            for (int i = 1; i <= access[4]; i++)
            {
                turnover(place + i);
                countershown[place + i] = access[0];
            }
            for (int i = 1; i <= access[5]; i++)
            {
                turnover(place - i);
                countershown[place - i] = access[0];
            }

            for (int i = 1; i <= access[8]; i++)
            {
                turnover(place + i * 7);
                countershown[place + i * 7] = access[0];
            }
            for (int i = 1; i <= access[9]; i++)
            {
                turnover(place - i * 7);
                countershown[place - i * 7] = access[0];
            }

            for (int i = 1; i <= access[6]; i++)
            {
                turnover(place + i * 9);
                countershown[place + i * 9] = access[0];
            }
            for (int i = 1; i <= access[7]; i++)
            {
                turnover(place - i * 9);
                countershown[place - i * 9] = access[0];
            }
        }
    }
}