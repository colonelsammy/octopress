﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        private void Change_diaginol7(int place)
        {
            if (access.tochange[0] == 2)
            {
                if (access.tochange[8] == 1)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                }
                if (access.tochange[8] == 2)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 2;
                }
                if (access.tochange[8] == 3)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 2;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 2;
                }
                if (access.tochange[8] == 4)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 2;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 2;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 2;
                }
                if (access.tochange[8] == 5)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 2;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 2;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 2;
                    turnover(place + 35);
                    Ai.access.checka[place + 35] = 2;
                }
                if (access.tochange[8] == 6)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 2;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 2;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 2;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 2;
                    turnover(place + 35);
                    Ai.access.checka[place + 35] = 2;
                    turnover(place + 42);
                    Ai.access.checka[place + 42] = 2;
                }

                if (access.tochange[9] == 1)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                }
                if (access.tochange[9] == 2)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 2;
                }
                if (access.tochange[9] == 3)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 2;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 2;
                }
                if (access.tochange[9] == 4)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 2;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 2;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 2;
                }
                if (access.tochange[9] == 5)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 2;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 2;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 2;
                    turnover(place - 35);
                    Ai.access.checka[place - 35] = 2;
                }
                if (access.tochange[9] == 6)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 2;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 2;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 2;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 2;
                    turnover(place - 35);
                    Ai.access.checka[place - 35] = 2;
                    turnover(place - 42);
                    Ai.access.checka[place - 42] = 2;
                }
            }
            else
            {
                if (access.tochange[8] == 1)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                }
                if (access.tochange[8] == 2)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 1;
                }
                if (access.tochange[8] == 3)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 1;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 1;
                }
                if (access.tochange[8] == 4)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 1;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 1;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 1;
                }
                if (access.tochange[8] == 5)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 1;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 1;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 1;
                    turnover(place + 35);
                    Ai.access.checka[place + 35] = 1;
                }
                if (access.tochange[8] == 6)
                {
                    turnover(place + 7);
                    Ai.access.checka[place + 7] = 1;
                    turnover(place + 14);
                    Ai.access.checka[place + 14] = 1;
                    turnover(place + 21);
                    Ai.access.checka[place + 21] = 1;
                    turnover(place + 28);
                    Ai.access.checka[place + 28] = 1;
                    turnover(place + 35);
                    Ai.access.checka[place + 35] = 1;
                    turnover(place + 42);
                    Ai.access.checka[place + 42] = 1;
                }

                if (access.tochange[9] == 1)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                }
                if (access.tochange[9] == 2)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 1;
                }
                if (access.tochange[9] == 3)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 1;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 1;
                }
                if (access.tochange[9] == 4)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 1;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 1;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 1;
                }
                if (access.tochange[9] == 5)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 1;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 1;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 1;
                    turnover(place - 35);
                    Ai.access.checka[place - 35] = 1;
                }
                if (access.tochange[9] == 6)
                {
                    turnover(place - 7);
                    Ai.access.checka[place - 7] = 1;
                    turnover(place - 14);
                    Ai.access.checka[place - 14] = 1;
                    turnover(place - 21);
                    Ai.access.checka[place - 21] = 1;
                    turnover(place - 28);
                    Ai.access.checka[place - 28] = 1;
                    turnover(place - 35);
                    Ai.access.checka[place - 35] = 1;
                    turnover(place - 42);
                    Ai.access.checka[place - 42] = 1;
                }
            }

        }
    }
}