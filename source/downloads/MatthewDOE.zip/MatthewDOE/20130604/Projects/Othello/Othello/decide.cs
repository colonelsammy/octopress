﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Othello
{
    public partial class AI
    {
        private void decide()
        {
            if ((able[0] == 1) || (able[7] == 1) || (able[56] == 1) || (able[63] == 1))
            {
                if (able[0] == 1)
                {
                    which[many] = 0;
                    many = many + 1;
                    gone = true;
                }
                if (able[7] == 1)
                {
                    which[many] = 7;
                    many = many + 1;
                    gone = true;
                }
                if (able[56] == 1)
                {
                    which[many] = 56;
                    many = many + 1;
                    gone = true;
                }
                if (able[63] == 1)
                {
                    which[many] = 63;
                    many = many + 1;
                    gone = true;
                }
                use = random.Next(many); 
            }
            if (gone == false)
            {
                if (able[2] == 1)
                {
                    which[many] = 2;
                    many = many + 1;
                    gone = true;
                }
                if (able[3] == 1)
                {
                    which[many] = 3;
                    many = many + 1;
                    gone = true;
                }
                if (able[4] == 1)
                {
                    which[many] = 4;
                    many = many + 1;
                    gone = true;
                }
                if (able[5] == 1)
                {
                    which[many] = 5;
                    many = many + 1;
                    gone = true;
                }

                if (able[23] == 1)
                {
                    which[many] = 23;
                    many = many + 1;
                    gone = true;
                }
                if (able[31] == 1)
                {
                    which[many] = 31;
                    many = many + 1;
                    gone = true;
                }
                if (able[39] == 1)
                {
                    which[many] = 39;
                    many = many + 1;
                    gone = true;
                }
                if (able[47] == 1)
                {
                    which[many] = 47;
                    many = many + 1;
                    gone = true;
                }
                if (able[61] == 1)
                {
                    which[many] = 61;
                    many = many + 1;
                    gone = true;
                }
                if (able[60] == 1)
                {
                    which[many] = 60;
                    many = many + 1;
                    gone = true;
                }
                if (able[59] == 1)
                {
                    which[many] = 59;
                    many = many + 1;
                    gone = true;
                }
                if (able[58] == 1)
                {
                    which[many] = 58;
                    many = many + 1;
                    gone = true;
                }
                if (able[40] == 1)
                {
                    which[many] = 40;
                    many = many + 1;
                    gone = true;
                }
                if (able[32] == 1)
                {
                    which[many] = 32;
                    many = many + 1;
                    gone = true;
                }
                if (able[24] == 1)
                {
                    which[many] = 24;
                    many = many + 1;
                    gone = true;
                }
                if (able[16] == 1)
                {
                    which[many] = 16;
                    many = many + 1;
                    gone = true;
                }
                use = random.Next(many);
            }
            if (gone == false)
            {
                if (able[18] == 1)
                {
                    which[many] = 18;
                    many = many + 1;
                    gone = true;
                }
                if (able[26] == 1)
                {
                    which[many] = 26;
                    many = many + 1;
                    gone = true;
                }
                if (able[34] == 1)
                {
                    which[many] = 34;
                    many = many + 1;
                    gone = true;
                }
                if (able[42] == 1)
                {
                    which[many] = 42;
                    many = many + 1;
                    gone = true;
                }
                if (able[43] == 1)
                {
                    which[many] = 43;
                    many = many + 1;
                    gone = true;
                }
                if (able[44] == 1)
                {
                    which[many] = 44;
                    many = many + 1;
                    gone = true;
                }
                if (able[45] == 1)
                {
                    which[many] = 45;
                    many = many + 1;
                    gone = true;
                }
                if (able[37] == 1)
                {
                    which[many] = 37;
                    many = many + 1;
                    gone = true;
                }
                if (able[29] == 1)
                {
                    which[many] = 29;
                    many = many + 1;
                    gone = true;
                }
                if (able[21] == 1)
                {
                    which[many] = 21;
                    many = many + 1;
                    gone = true;
                }
                if (able[20] == 1)
                {
                    which[many] = 20;
                    many = many + 1;
                    gone = true;
                }
                if (able[19] == 1)
                {
                    which[many] = 19;
                    many = many + 1;
                    gone = true;
                }
                use = random.Next(0, many);
            }
            if (gone == false)
            {
                if (able[10] == 1)
                {
                    which[many] = 10;
                    many = many + 1;
                    gone = true;
                }
                if (able[11] == 1)
                {
                    which[many] = 11;
                    many = many + 1;
                    gone = true;
                }
                if (able[12] == 1)
                {
                    which[many] = 12;
                    many = many + 1;
                    gone = true;
                }
                if (able[13] == 1)
                {
                    which[many] = 13;
                    many = many + 1;
                    gone = true;
                }

                if (able[22] == 1)
                {
                    which[many] = 22;
                    many = many + 1;
                    gone = true;
                }
                if (able[30] == 1)
                {
                    which[many] = 30;
                    many = many + 1;
                    gone = true;
                }
                if (able[38] == 1)
                {
                    which[many] = 38;
                    many = many + 1;
                    gone = true;
                }
                if (able[46] == 1)
                {
                    which[many] = 46;
                    many = many + 1;
                    gone = true;
                }
                if (able[53] == 1)
                {
                    which[many] = 53;
                    many = many + 1;
                    gone = true;
                }
                if (able[52] == 1)
                {
                    which[many] = 52;
                    many = many + 1;
                    gone = true;
                }
                if (able[51] == 1)
                {
                    which[many] = 51;
                    many = many + 1;
                    gone = true;
                }
                if (able[50] == 1)
                {
                    which[many] = 50;
                    many = many + 1;
                    gone = true;
                }
                if (able[41] == 1)
                {
                    which[many] = 41;
                    many = many + 1;
                    gone = true;
                }
                if (able[33] == 1)
                {
                    which[many] = 33;
                    many = many + 1;
                    gone = true;
                }
                if (able[25] == 1)
                {
                    which[many] = 25;
                    many = many + 1;
                    gone = true;
                }
                if (able[17] == 1)
                {
                    which[many] = 17;
                    many = many + 1;
                    gone = true;
                }
                use = random.Next(0, many);
            }
            if (gone == false)
            {
                if (able[8] == 1)
                {
                    which[many] = 8;
                    many = many + 1;
                    gone = true;
                }
                if (able[9] == 1)
                {
                    which[many] = 9;
                    many = many + 1;
                    gone = true;
                }
                if (able[1] == 1)
                {
                    which[many] = 1;
                    many = many + 1;
                    gone = true;
                }
                if (able[6] == 1)
                {
                    which[many] = 6;
                    many = many + 1;
                    gone = true;
                }
                if (able[14] == 1)
                {
                    which[many] = 14;
                    many = many + 1;
                    gone = true;
                }
                if (able[15] == 1)
                {
                    which[many] = 15;
                    many = many + 1;
                    gone = true;
                }
                if (able[55] == 1)
                {
                    which[many] = 55;
                    many = many + 1;
                    gone = true;
                }
                if (able[54] == 1)
                {
                    which[many] = 54;
                    many = many + 1;
                    gone = true;
                }
                if (able[62] == 1)
                {
                    which[many] = 62;
                    many = many + 1;
                    gone = true;
                }
                if (able[57] == 1)
                {
                    which[many] = 57;
                    many = many + 1;
                    gone = true;
                }
                if (able[49] == 1)
                {
                    which[many] = 49;
                    many = many + 1;
                    gone = true;
                }
                if (able[48] == 1)
                {
                    which[many] = 48;
                    many = many + 1;
                    gone = true;
                }
                use = random.Next(0, many);
            }
            if (which[use] < 8)
            {
                coloumn = 1;
            }
            if ((which[use] > 7) && (which[use] < 16))
            {
                coloumn = 2;
            }
            if ((which[use] > 15) && (which[use] < 24))
            {
                coloumn = 3;
            }
            if ((which[use] > 23) && (which[use] < 32))
            {
                coloumn = 4;
            }
            if ((which[use] > 31) && (which[use] < 40))
            {
                coloumn = 5;
            }
            if ((which[use] > 39) && (which[use] < 48))
            {
                coloumn = 6;
            }
            if ((which[use] > 47) && (which[use] < 56))
            {
                coloumn = 7;
            }
            if ((which[use] > 55) && (which[use] < 64))
            {
                coloumn = 8;
            }
        }
    }
}