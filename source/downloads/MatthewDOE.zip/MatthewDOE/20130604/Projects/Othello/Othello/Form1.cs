﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Othello
{
    public partial class Board : Form
    {
        int turn = 1;
        int playerturn = 2;
        int bnumber = 0;
        int wnumber = 0;
        string file;
        private Place access;
        private AI Ai;
        private List<Piece>black;
        private List<StreamWriter> Saver;
        private List<StreamReader> Reader;

        public Board()
        {
            InitializeComponent();
            player2select.Hide();
            access = new Place();
            access.setup();
            Ai = new AI();
            Ai.setup();
            black = new List<Piece>();
            Saver = new List<StreamWriter>();
            Reader = new List<StreamReader>();
            end_turn();
            picture();
            if (MessageBox.Show("Do you want to play the computer?", "1 or 2 player", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                Ai.on = false;
            }
            
            
        }

        public void turnover(int peice)
        {
            if (access.tochange[0] == 1)
            {
                black[peice].Picture.Image = Othello.Properties.Resources.black;
            }
            else
            {
                black[peice].Picture.Image = Othello.Properties.Resources.white;
            }
            
        }

        public void aiturn(int place, int coloumn)
        {
            turn = access.turnpiece(2, place, coloumn);
            change(2, turn);
        }

        private void end_turn()
        {
            number();
            if (playerturn == 1)
            {
                player1select.Hide();
                player2select.Show();
                playerturn = 2;
                
            }
            else
            {
                player1select.Show();
                player2select.Hide();
                playerturn = 1;
            }
        }

        private void end_Click(object sender, EventArgs e)
        {
            end_turn();
        }

        private void reset_Click(object sender, EventArgs e)
        {
            
        }

        private void green11_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,0,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,0,1);
                change(2, turn);
            }
        
        }

        private void green21_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,1,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,1,1);
                change(2, turn);
            }
        }

        private void green31_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,2,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,2,1);
                change(2, turn);
            }
        }

        private void green41_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,3,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,3,1);
                change(2, turn);
            }
        }

        private void green51_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,4,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,4,1);
                change(2, turn);
            }
        }

        private void green61_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,5,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,5,1);
                change(2, turn);
            }
        }

        private void green71_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,6,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,6,1);
                change(2, turn);
            }
        }

        private void green81_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,7,1);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,7,1);
                change(2, turn);
            }
        }

        private void green12_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,8,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,8,2);
                change(2, turn);
            }
        }

        private void green22_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,9,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,9,2);
                change(2, turn);
            }
        }

        private void green32_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,10,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,10,2);
                change(2, turn);
            }
        }

        private void green42_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,11,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,11,2);
                change(2, turn);
            }
        }

        private void green52_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,12,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,12,2);
                change(2, turn);
            }
        }

        private void green62_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,13,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,13,2);
                change(2, turn);
            }
        }

        private void green72_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,14,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,14,2);
                change(2, turn);
            }
        }

        private void green82_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,15,2);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,15,2);
                change(2, turn);
            }
        }

        private void green13_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,16,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,16,3);
                change(2, turn);
            }
        }

        private void green23_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,17,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,17,3);
                change(2, turn);
            }
        }

        private void green33_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,18,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,18,3);
                change(2, turn);
            }
        }

        private void green43_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,19,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,19,3);
                change(2, turn);
            }
        }

        private void green53_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,20,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,20,3);
                change(2, turn);
            }
        }

        private void green63_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,21,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,21,3);
                change(2, turn);
            }
        }

        private void green73_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,22,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,22,3);
                change(2, turn);
            }
        }

        private void green83_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,23,3);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,23,3);
                change(2, turn);
            }
        }

        private void green14_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,24,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,24,4);
                change(2, turn);
            }
        }

        private void green24_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,25,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,25,4);
                change(2, turn);
            }
        }

        private void green34_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,26,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,26,4);
                change(2, turn);
            }
        }

        private void green44_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,27,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,27,4);
                change(2, turn);
            }
        }

        private void green54_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,28,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,28,4);
                change(2, turn);
            }
        }

        private void green64_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,29,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,29,4);
                change(2, turn);
            }
        }

        private void green74_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,30,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,30,4);
                change(2, turn);
            }
        }

        private void green84_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,31,4);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,31,4);
                change(2, turn);
            }
        }

        private void green15_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,32,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,32,5);
                change(2, turn);
            }
        }

        private void green25_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,33,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,33,5);
                change(2, turn);
            }
        }

        private void green35_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,34,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,34,5);
                change(2, turn);
            }
        }

        private void green45_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,35,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,35,5);
                change(2, turn);
            }
        }

        private void green55_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,36,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,36,5);
                change(2, turn);
            }
        }

        private void green65_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,37,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,37,5);
                change(2, turn);
            }
        }

        private void green75_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,38,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,38,5);
                change(2, turn);
            }
        }

        private void green85_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,39,5);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,39,5);
                change(2, turn);
            }
        }

        private void green16_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,40,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,40,6);
                change(2, turn);
            }
        }

        private void green26_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,41,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,41,6);
                change(2, turn);
            }
        }

        private void green36_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,42,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,42,6);
                change(2, turn);
            }
        }

        private void green46_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,43,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,43,6);
                change(2, turn);
            }
        }

        private void green56_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,44,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,44,6);
                change(2, turn);
            }
        }

        private void green66_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,45,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,45,6);
                change(2, turn);
            }
        }

        private void green76_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,46,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,46,6);
                change(2, turn);
            }
        }

        private void green86_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,47,6);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,47,6);
                change(2, turn);
            }
        }

        private void green17_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,48,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,48,7);
                change(2, turn);
            }
        }

        private void green27_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,49,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,49,7);
                change(2, turn);
            }
        }

        private void green37_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,50,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,50,7);
                change(2, turn);
            }
        }

        private void green47_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,51,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,51,7);
                change(2, turn);
            }
        }

        private void green57_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,52,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,52,7);
                change(2, turn);
            }
        }

        private void green67_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,53,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,53,7);
                change(2, turn);
            }
        }

        private void green77_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,54,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,54,7);
                change(2, turn);
            }
        }

        private void green87_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,55,7);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,55,7);
                change(2, turn);
            }
        }

        private void green18_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,56,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,56,8);
                change(2, turn);
            }
        }

        private void green28_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,57,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,57,8);
                change(2, turn);
            }
        }

        private void green38_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,58,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,58,8);
                change(2, turn);
            }
        }

        private void green48_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,59,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,59,8);
                change(2, turn);
            }
        }

        private void green58_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,60,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,60,8);
                change(2, turn);
            }
        }

        private void green68_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,61,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,61,8);
                change(2, turn);
            }
        }

        private void green78_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,62,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,62,8);
                change(2, turn);
            }
        }

        private void green88_Click(object sender, EventArgs e)
        {
            if (player1select.Visible == true)
            {
                turn = access.turnpiece(1,63,8);
                change(1, turn);
            }
            else
            {
                turn = access.turnpiece(2,63,8);
                change(2, turn);
            }
        }

        private void helpbutton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is othello");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Aitimer.Stop();
            Ai.run();
            aiturn(Ai.which[Ai.use], Ai.coloumn);
            Ai.turn = false;
            
        }

        private void Save_Click(object sender, EventArgs e)
        {
            file = Filename.Text;
            Savegame(file);
        }

        private void Load_Click(object sender, EventArgs e)
        {
            file = Filename.Text;
            Loadgame(file);
        }
    }
}
