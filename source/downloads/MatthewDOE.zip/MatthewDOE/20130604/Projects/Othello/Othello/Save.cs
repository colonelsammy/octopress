﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Othello
{
    public partial class Board
    {
        public void Savegame(string filename)
        {
            filename = filename + ".txt";
            Saver.Add(new StreamWriter(filename, false));
            for (int x = 0; x < 64; x = x + 1)
            {
                Saver[0].Write(Ai.access.checka[x]);
            }
            if (playerturn == 1)
            {
                Saver[0].Write(2);
            }
            else
            {
                Saver[0].Write(1);
            }
            Saver[0].Close();
            Saver.RemoveAt(0);

        }
        public void Loadgame(string filename)
        {
            int read = 0;
            for (int x = 0; x < 64; x = x + 1)
            {
                black[x].Picture.Hide();
                Ai.access.checka[x] = 0;
            }
            filename = filename + ".txt";
            Reader.Add(new StreamReader(filename));
            for (int x = 0; x < 64; x = x + 1)
            {
                read = Reader[0].Read();
                listBox1.Items.Add(read);
                if (read == 1)
                {
                    black[x].Picture.Show();
                    black[x].Picture.Image = Othello.Properties.Resources.black;
                    Ai.access.checka[x] = 1;
                }
                if (read == 2)
                {
                    black[x].Picture.Show();
                    black[x].Picture.Image = Othello.Properties.Resources.white;
                    Ai.access.checka[x] = 2;
                }
            }
            playerturn = Reader[0].Read();
            end_turn();
            for (int x = 0; x < 64; x = x + 1)
            {
                access.checka[x] = Ai.access.checka[x];
            }
            Reader[0].Close();
            Reader.RemoveAt(0);
        }
    }
}