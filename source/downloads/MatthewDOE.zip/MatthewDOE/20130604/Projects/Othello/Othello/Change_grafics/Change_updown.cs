﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        private void change_updown(int place)
        {
            if (access.tochange[0] == 2)
            {
                if (access.tochange[4] == 1)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                }
                if (access.tochange[4] == 2)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 2;
                }
                if (access.tochange[4] == 3)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 2;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 2;
                }
                if (access.tochange[4] == 4)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 2;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 2;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 2;
                }
                if (access.tochange[4] == 5)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 2;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 2;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 2;
                    turnover(place + 5);
                    Ai.access.checka[place + 5] = 2;
                }
                if (access.tochange[4] == 6)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 2;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 2;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 2;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 2;
                    turnover(place + 5);
                    Ai.access.checka[place + 5] = 2;
                    turnover(place + 6);
                    Ai.access.checka[place + 6] = 2;
                }

                if (access.tochange[5] == 1)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                }
                if (access.tochange[5] == 2)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 2;
                }
                if (access.tochange[5] == 3)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 2;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 2;
                }
                if (access.tochange[5] == 4)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 2;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 2;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 2;
                }
                if (access.tochange[5] == 5)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 2;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 2;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 2;
                    turnover(place - 5);
                    Ai.access.checka[place - 5] = 2;
                }
                if (access.tochange[5] == 6)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 2;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 2;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 2;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 2;
                    turnover(place - 5);
                    Ai.access.checka[place - 5] = 2;
                    turnover(place - 6);
                    Ai.access.checka[place - 6] = 2;
                }
            }
            else
            {
                if (access.tochange[4] == 1)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                }
                if (access.tochange[4] == 2)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 1;
                }
                if (access.tochange[4] == 3)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 1;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 1;
                }
                if (access.tochange[4] == 4)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 1;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 1;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 1;
                }
                if (access.tochange[4] == 5)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 1;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 1;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 1;
                    turnover(place + 5);
                    Ai.access.checka[place + 5] = 1;
                }
                if (access.tochange[4] == 6)
                {
                    turnover(place + 1);
                    Ai.access.checka[place + 1] = 1;
                    turnover(place + 2);
                    Ai.access.checka[place + 2] = 1;
                    turnover(place + 3);
                    Ai.access.checka[place + 3] = 1;
                    turnover(place + 4);
                    Ai.access.checka[place + 4] = 1;
                    turnover(place + 5);
                    Ai.access.checka[place + 5] = 1;
                    turnover(place + 6);
                    Ai.access.checka[place + 6] = 1;
                }

                if (access.tochange[5] == 1)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                }
                if (access.tochange[5] == 2)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 1;
                }
                if (access.tochange[5] == 3)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 1;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 1;
                }
                if (access.tochange[5] == 4)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 1;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 1;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 1;
                }
                if (access.tochange[5] == 5)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 1;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 1;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 1;
                    turnover(place - 5);
                    Ai.access.checka[place - 5] = 1;
                }
                if (access.tochange[5] == 6)
                {
                    turnover(place - 1);
                    Ai.access.checka[place - 1] = 1;
                    turnover(place - 2);
                    Ai.access.checka[place - 2] = 1;
                    turnover(place - 3);
                    Ai.access.checka[place - 3] = 1;
                    turnover(place - 4);
                    Ai.access.checka[place - 4] = 1;
                    turnover(place - 5);
                    Ai.access.checka[place - 5] = 1;
                    turnover(place - 6);
                    Ai.access.checka[place - 6] = 1;
                }
            }
        }
    }
}