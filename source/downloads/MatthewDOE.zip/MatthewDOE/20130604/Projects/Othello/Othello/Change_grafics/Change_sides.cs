﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        private void Change_sides(int place)
        {
            if (access.tochange[0] == 2)
            {
                if (access.tochange[2] == 1)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                }
                if (access.tochange[2] == 2)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 2;
                }
                if (access.tochange[2] == 3)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 2;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 2;
                }
                if (access.tochange[2] == 4)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 2;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 2;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 2;
                }
                if (access.tochange[2] == 5)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 2;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 2;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 2;
                    turnover(place + 40);
                    Ai.access.checka[place + 40] = 2;
                }
                if (access.tochange[2] == 6)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 2;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 2;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 2;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 2;
                    turnover(place + 40);
                    Ai.access.checka[place + 40] = 2;
                    turnover(place + 48);
                    Ai.access.checka[place + 48] = 2;
                }

                if (access.tochange[3] == 1)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                }
                if (access.tochange[3] == 2)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 2;
                }
                if (access.tochange[3] == 3)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 2;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 2;
                }
                if (access.tochange[3] == 4)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 2;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 2;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 2;
                }
                if (access.tochange[3] == 5)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 2;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 2;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 2;
                    turnover(place - 40);
                    Ai.access.checka[place - 40] = 2;
                }
                if (access.tochange[3] == 6)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 2;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 2;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 2;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 2;
                    turnover(place - 40);
                    Ai.access.checka[place - 40] = 2;
                    turnover(place - 48);
                    Ai.access.checka[place - 48] = 2;
                }
            }
            else
            {
                if (access.tochange[2] == 1)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                }
                if (access.tochange[2] == 2)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 1;
                }
                if (access.tochange[2] == 3)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 1;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 1;
                }
                if (access.tochange[2] == 4)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 1;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 1;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 1;
                }
                if (access.tochange[2] == 5)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 1;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 1;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 1;
                    turnover(place + 40);
                    Ai.access.checka[place + 40] = 1;
                }
                if (access.tochange[2] == 6)
                {
                    turnover(place + 8);
                    Ai.access.checka[place + 8] = 1;
                    turnover(place + 16);
                    Ai.access.checka[place + 16] = 1;
                    turnover(place + 24);
                    Ai.access.checka[place + 24] = 1;
                    turnover(place + 32);
                    Ai.access.checka[place + 32] = 1;
                    turnover(place + 40);
                    Ai.access.checka[place + 40] = 1;
                    turnover(place + 48);
                    Ai.access.checka[place + 48] = 1;
                }

                if (access.tochange[3] == 1)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                }
                if (access.tochange[3] == 2)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 1;
                }
                if (access.tochange[3] == 3)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 1;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 1;
                }
                if (access.tochange[3] == 4)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 1;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 1;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 1;
                }
                if (access.tochange[3] == 5)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 1;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 1;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 1;
                    turnover(place - 40);
                    Ai.access.checka[place - 40] = 1;
                }
                if (access.tochange[3] == 6)
                {
                    turnover(place - 8);
                    Ai.access.checka[place - 8] = 1;
                    turnover(place - 16);
                    Ai.access.checka[place - 16] = 1;
                    turnover(place - 24);
                    Ai.access.checka[place - 24] = 1;
                    turnover(place - 32);
                    Ai.access.checka[place - 32] = 1;
                    turnover(place - 40);
                    Ai.access.checka[place - 40] = 1;
                    turnover(place - 48);
                    Ai.access.checka[place - 48] = 1;
                }
            }
        }
    }
}