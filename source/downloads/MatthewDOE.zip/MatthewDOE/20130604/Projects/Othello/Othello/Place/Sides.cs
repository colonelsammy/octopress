﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {
        public void sides(int player, int place)
        {
            if (player == 1)
            {
                if (place + 56 < 64)
                {
                    if ((checka[place + 56] == 1) && (checka[place + 48] == 2) && (checka[place + 40] == 2)
                        && (checka[place + 32] == 2) && (checka[place + 24] == 2) && (checka[place + 16] == 2) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 6;
                    }
                }

                if (place + 48 < 64)
                {
                    if ((checka[place + 48] == 1) && (checka[place + 40] == 2) && (checka[place + 32] == 2)
                                && (checka[place + 24] == 2) && (checka[place + 16] == 2) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 5;
                    }
                }

                if (place + 40 < 64)
                {
                    if ((checka[place + 40] == 1) && (checka[place + 32] == 2)
                       && (checka[place + 24] == 2) && (checka[place + 16] == 2) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 4;
                    }
                }

                if (place + 32 < 64)
                {
                    if ((checka[place + 32] == 1) && (checka[place + 24] == 2) && (checka[place + 16] == 2) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 3;
                    }
                }

                if (place + 24 < 64)
                {
                    if ((checka[place + 24] == 1) && (checka[place + 16] == 2) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 2;
                    }
                }

                if (place + 16 < 64)
                {
                    if ((checka[place + 16] == 1) && (checka[place + 8] == 2))
                    {
                        tochange[2] = 1;
                    }
                }



                if (place - 56 > 0)
                {
                    if ((checka[place - 56] == 1) && (checka[place - 48] == 2) && (checka[place - 40] == 2)
                        && (checka[place - 32] == 2) && (checka[place - 24] == 2) && (checka[place - 16] == 2) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 6;
                    }
                }

                if (place - 48 > 0)
                {
                    if ((checka[place - 48] == 1) && (checka[place - 40] == 2) && (checka[place - 32] == 2)
                                && (checka[place - 24] == 2) && (checka[place - 16] == 2) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 5;
                    }
                }

                if (place - 40 > 0)
                {
                    if ((checka[place - 40] == 1) && (checka[place - 32] == 2)
                       && (checka[place - 24] == 2) && (checka[place - 16] == 2) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 4;
                    }
                }

                if (place - 32 > 0)
                {
                    if ((checka[place - 32] == 1) && (checka[place - 24] == 2) && (checka[place - 16] == 2) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 3;
                    }
                }

                if (place - 24 > 0)
                {
                    if ((checka[place - 24] == 1) && (checka[place - 16] == 2) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 2;
                    }
                }

                if (place - 16 > 0)
                {
                    if ((checka[place - 16] == 1) && (checka[place - 8] == 2))
                    {
                        tochange[3] = 1;
                    }
                }
            }
            else
            {
                if (place + 56 < 64)
                {
                    if ((checka[place + 56] == 2) && (checka[place + 48] == 1) && (checka[place + 40] == 1)
                        && (checka[place + 32] == 1) && (checka[place + 24] == 1) && (checka[place + 16] == 1) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 6;
                    }
                }

                if (place + 48 < 64)
                {
                    if ((checka[place + 48] == 2) && (checka[place + 40] == 1) && (checka[place + 32] == 1)
                                && (checka[place + 24] == 1) && (checka[place + 16] == 1) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 5;
                    }
                }

                if (place + 40 < 64)
                {
                    if ((checka[place + 40] == 2) && (checka[place + 32] == 1)
                       && (checka[place + 24] == 1) && (checka[place + 16] == 1) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 4;
                    }
                }

                if (place + 32 < 64)
                {
                    if ((checka[place + 32] == 2) && (checka[place + 24] == 1) && (checka[place + 16] == 1) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 3;
                    }
                }

                if (place + 24 < 64)
                {
                    if ((checka[place + 24] == 2) && (checka[place + 16] == 1) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 2;
                    }
                }

                if (place + 16 < 64)
                {
                    if ((checka[place + 16] == 2) && (checka[place + 8] == 1))
                    {
                        tochange[2] = 1;
                    }
                }



                if (place - 56 > 0)
                {
                    if ((checka[place - 56] == 2) && (checka[place - 48] == 1) && (checka[place - 40] == 1)
                        && (checka[place - 32] == 1) && (checka[place - 24] == 1) && (checka[place - 16] == 1) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 6;
                    }
                }

                if (place - 48 > 0)
                {
                    if ((checka[place - 48] == 2) && (checka[place - 40] == 1) && (checka[place - 32] == 1)
                                && (checka[place - 24] == 1) && (checka[place - 16] == 1) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 5;
                    }
                }

                if (place - 40 > 0)
                {
                    if ((checka[place - 40] == 2) && (checka[place - 32] == 1)
                       && (checka[place - 24] == 1) && (checka[place - 16] == 1) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 4;
                    }
                }

                if (place - 32 > 0)
                {
                    if ((checka[place - 32] == 2) && (checka[place - 24] == 1) && (checka[place - 16] == 1) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 3;
                    }
                }

                if (place - 24 > 0)
                {
                    if ((checka[place - 24] == 2) && (checka[place - 16] == 1) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 2;
                    }
                }

                if (place - 16 > 0)
                {
                    if ((checka[place - 16] == 2) && (checka[place - 8] == 1))
                    {
                        tochange[3] = 1;
                    }
                }
            }
        }
    }
}