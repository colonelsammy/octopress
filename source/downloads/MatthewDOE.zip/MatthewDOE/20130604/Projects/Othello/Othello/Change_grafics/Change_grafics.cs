﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        public void change(int player, int change)
        {
            if ((Ai.on == false) || (playerturn == 1) || (Ai.turn == true))
            {
                if (((access.tochange[2] == 0) && (access.tochange[3] == 0) && (access.tochange[4] == 0)
                && (access.tochange[5] == 0) && (access.tochange[6] == 0) && (access.tochange[7] == 0)
                && (access.tochange[8] == 0) && (access.tochange[9] == 0)) || (access.checka[access.tochange[1]] > 0))
                {
                    MessageBox.Show("You can't go there");

                    black[access.tochange[1]].Picture.Hide();
                    if (Ai.access.checka[access.tochange[1]] == 1)
                    {
                        black[access.tochange[1]].Picture.Show();
                        black[access.tochange[1]].Picture.Image = Othello.Properties.Resources.black;
                    }
                    if (Ai.access.checka[access.tochange[1]] == 2)
                    {
                        black[access.tochange[1]].Picture.Show();
                        black[access.tochange[1]].Picture.Image = Othello.Properties.Resources.white;
                    }
                }
                else
                {
                    if (access.tochange[0] == 1)
                    {
                        Ai.access.checka[access.tochange[1]] = 1;
                        black[access.tochange[1]].Picture.Show();
                    }
                    else
                    {
                        Ai.access.checka[access.tochange[1]] = 2;
                        black[access.tochange[1]].Picture.Show();
                        black[access.tochange[1]].Picture.Image = Othello.Properties.Resources.white;
                    }
                    Change_sides(access.tochange[1]);
                    change_updown(access.tochange[1]);
                    Change_diaginol7(access.tochange[1]);
                    Change_diaginol9(access.tochange[1]);
                    for (int x = 0; x < 64; x = x + 1)
                    {
                        access.checka[x] = Ai.access.checka[x];
                    }
                    end_turn();
                    if ((Ai.on == true) && (playerturn == 2))
                    {
                        Ai.turn = true;
                        Aitimer.Start();
                    }

                }
            }
            
        }

        private void number()
        {
            bnumber = 0;
            wnumber = 0;
            for (int x = 0; x < 64; x = x + 1)
            {
                if (Ai.access.checka[x] == 1)
                {
                    bnumber = bnumber + 1;
                }
                if (Ai.access.checka[x] == 2)
                {
                    wnumber = wnumber + 1;
                }
            }
            player1count.Items.Clear();
            player1count.Items.Add(bnumber);
            player2count.Items.Clear();
            player2count.Items.Add(wnumber);
        }
    }
}