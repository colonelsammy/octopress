﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {
        public void updown(int player, int place, int coloumn)
        {
            int coloumna = coloumn * 8;
            int coloumnb = (coloumn - 1) * 8;

            if (player == 1)
            {
                if (place + 7 < coloumna)
                {
                    if ((checka[place + 7] == 1) && (checka[place + 6] == 2) && (checka[place + 5] == 2)
                        && (checka[place + 4] == 2) && (checka[place + 3] == 2) && (checka[place + 2] == 2) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 6;
                    }
                }

                if (place + 6 < coloumna)
                {
                    if ((checka[place + 6] == 1) && (checka[place + 5] == 2) && (checka[place + 4] == 2)
                                && (checka[place + 3] == 2) && (checka[place + 2] == 2) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 5;
                    }
                }

                if (place + 5 < coloumna)
                {
                    if ((checka[place + 5] == 1) && (checka[place + 4] == 2)
                       && (checka[place + 3] == 2) && (checka[place + 2] == 2) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 4;
                    }
                }

                if (place + 4 < coloumna)
                {
                    if ((checka[place + 4] == 1) && (checka[place + 3] == 2) && (checka[place + 2] == 2) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 3;
                    }
                }

                if (place + 3 < coloumna)
                {
                    if ((checka[place + 3] == 1) && (checka[place + 2] == 2) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 2;
                    }
                }

                if (place + 2 < coloumna)
                {
                    if ((checka[place + 2] == 1) && (checka[place + 1] == 2))
                    {
                        tochange[4] = 1;
                    }
                }



                if (place - 7 > coloumnb)
                {
                    if ((checka[place - 7] == 1) && (checka[place - 6] == 2) && (checka[place - 5] == 2)
                        && (checka[place - 4] == 2) && (checka[place - 3] == 2) && (checka[place - 2] == 2) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 6;
                    }
                }

                if (place - 6 > coloumnb)
                {
                    if ((checka[place - 6] == 1) && (checka[place - 5] == 2) && (checka[place - 4] == 2)
                                && (checka[place - 3] == 2) && (checka[place - 2] == 2) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 5;
                    }
                }

                if (place - 5 > coloumnb)
                {
                    if ((checka[place - 5] == 1) && (checka[place - 4] == 2)
                       && (checka[place - 3] == 2) && (checka[place - 2] == 2) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 4;
                    }
                }

                if (place - 4 > coloumnb)
                {
                    if ((checka[place - 4] == 1) && (checka[place - 3] == 2) && (checka[place - 2] == 2) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 3;
                    }
                }

                if (place - 3 > coloumnb)
                {
                    if ((checka[place - 3] == 1) && (checka[place - 2] == 2) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 2;
                    }
                }

                if (place - 2 > coloumnb)
                {
                    if ((checka[place - 2] == 1) && (checka[place - 1] == 2))
                    {
                        tochange[5] = 1;
                    }
                }
            }
            else
            {
                if (place + 7 < coloumna)
                {
                    if ((checka[place + 7] == 2) && (checka[place + 6] == 1) && (checka[place + 5] == 1)
                        && (checka[place + 4] == 1) && (checka[place + 3] == 1) && (checka[place + 2] == 1) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 6;
                    }
                }

                if (place + 6 < coloumna)
                {
                    if ((checka[place + 6] == 2) && (checka[place + 5] == 1) && (checka[place + 4] == 1)
                                && (checka[place + 3] == 1) && (checka[place + 2] == 1) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 5;
                    }
                }

                if (place + 5 < coloumna)
                {
                    if ((checka[place + 5] == 2) && (checka[place + 4] == 1)
                       && (checka[place + 3] == 1) && (checka[place + 2] == 1) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 4;
                    }
                }

                if (place + 4 < coloumna)
                {
                    if ((checka[place + 4] == 2) && (checka[place + 3] == 1) && (checka[place + 2] == 1) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 3;
                    }
                }

                if (place + 3 < coloumna)
                {
                    if ((checka[place + 3] == 2) && (checka[place + 2] == 1) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 2;
                    }
                }

                if (place + 2 < coloumna)
                {
                    if ((checka[place + 2] == 2) && (checka[place + 1] == 1))
                    {
                        tochange[4] = 1;
                    }
                }



                if (place - 7 > coloumnb)
                {
                    if ((checka[place - 7] == 2) && (checka[place - 6] == 1) && (checka[place - 5] == 1)
                        && (checka[place - 4] == 1) && (checka[place - 3] == 1) && (checka[place - 2] == 1) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 6;
                    }
                }

                if (place - 6 > coloumnb)
                {
                    if ((checka[place - 6] == 2) && (checka[place - 5] == 1) && (checka[place - 4] == 1)
                                && (checka[place - 3] == 1) && (checka[place - 2] == 1) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 5;
                    }
                }

                if (place - 5 > coloumnb)
                {
                    if ((checka[place - 5] == 2) && (checka[place - 4] == 1)
                       && (checka[place - 3] == 1) && (checka[place - 2] == 1) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 4;
                    }
                }

                if (place - 4 > coloumnb)
                {
                    if ((checka[place - 4] == 2) && (checka[place - 3] == 1) && (checka[place - 2] == 1) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 3;
                    }
                }

                if (place - 3 > coloumnb)
                {
                    if ((checka[place - 3] == 2) && (checka[place - 2] == 1) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 2;
                    }
                }

                if (place - 2 > coloumnb)
                {
                    if ((checka[place - 2] == 2) && (checka[place - 1] == 1))
                    {
                        tochange[5] = 1;
                    }
                }
            }
        }
    }
}