﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Othello
{
    public partial class AI
    {
        public bool on = true;
        public bool turn = false;
        private bool gone = false;
        public Place access;
        private Random random;
        public List<int> able;
        public List<int> which;
        private int many = 0;
        public int coloumn = 0;
        public int use = 0;
        public int checka = 0;

        public void setup()
        {
            access = new Place();
            access.setup();
            able = new List<int>();
            which = new List<int>();
            random = new Random();
            for (int x = 0; x < 64; x = x + 1)
            {
                able.Add(0);
            }
            for (int x = 0; x < 16; x = x + 1)
            {
                which.Add(0);
            }
        }

        public void run()
        {
            for (int x = 0; x < 16; x = x + 1)
            {
                which[x] = 0;
            }
            many = 0;
            gone = false;
            check();
            decide();
        }

        public void check()
        {
            for (int x = 0; x < 64; x = x + 1)
            {
                if (x < 8)
                {
                    coloumn = 1;
                }
                if ((x > 7) && (x < 16))
                {
                    coloumn = 2;
                }
                if ((x > 15) && (x < 24))
                {
                    coloumn = 3;
                }
                if ((x > 23) && (x < 32))
                {
                    coloumn = 4;
                } 
                if ((x > 31) && (x < 40))
                {
                    coloumn = 5;
                }
                if ((x > 39) && (x < 48))
                {
                    coloumn = 6;
                }
                if ((x > 47) && (x < 56))
                {
                    coloumn = 7;
                }
                if ((x > 55) && (x < 64))
                {
                    coloumn = 8;
                }
                access.turnpiece(2, x, coloumn);

                if (x == 29)
                {
                    checka = access.tochange[5];
                }

                if ((access.tochange[2] == 0) && (access.tochange[3] == 0) && (access.tochange[4] == 0)
                && (access.tochange[5] == 0) && (access.tochange[6] == 0) && (access.tochange[7] == 0)
                && (access.tochange[8] == 0) && (access.tochange[9] == 0))
                {
                    able[x] = 0;
                }
                else
                {
                    if (access.checka[access.tochange[1]] > 0)
                    {
                        able[x] = 0;
                    }
                    else
                    {
                        able[x] = 1;
                    }
                }
            }
        }
    }
}
