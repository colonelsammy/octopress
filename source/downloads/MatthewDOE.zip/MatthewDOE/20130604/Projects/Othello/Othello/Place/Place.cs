﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {
        public List<int> checka = new List<int>();
        public List<int> tochange = new List<int>();
        public bool shown = false;

        // 0 is player, 1 is place, 2 is right, 3 is left, 4 is up, 5 is down
        // 6 is +9, 7 is -9

        public int turnpiece(int player, int place, int coloumn)
        {
            for (int x = 0; x < 10; x = x + 1)
            {
                tochange[x] = 0;
            }
            shown = false;
            sides(player, place);
            updown(player, place, coloumn);
            diaginol7(player, place, coloumn);
            diaginol9(player, place, coloumn);
            tochange[0] = player;
            tochange[1] = place;
            return 2;
        }

        public void setup()
        {
            for (int x = 0; x < 64; x = x + 1)
            {
                checka.Add(0);
            }
            checka[27] = 2;
            checka[28] = 1;
            checka[35] = 1;
            checka[36] = 2;
            for (int x = 0; x < 10; x = x + 1)
            {
                tochange.Add(0);
            }
        }
         
    }
}
