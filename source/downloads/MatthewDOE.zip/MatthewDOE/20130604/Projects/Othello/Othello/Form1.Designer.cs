﻿namespace Othello
{
    partial class Board
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Board));
            this.player1 = new System.Windows.Forms.PictureBox();
            this.player2 = new System.Windows.Forms.PictureBox();
            this.player1select = new System.Windows.Forms.PictureBox();
            this.player2select = new System.Windows.Forms.PictureBox();
            this.background = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.green11 = new System.Windows.Forms.PictureBox();
            this.black11 = new System.Windows.Forms.PictureBox();
            this.green41 = new System.Windows.Forms.PictureBox();
            this.green31 = new System.Windows.Forms.PictureBox();
            this.green21 = new System.Windows.Forms.PictureBox();
            this.black31 = new System.Windows.Forms.PictureBox();
            this.black21 = new System.Windows.Forms.PictureBox();
            this.black41 = new System.Windows.Forms.PictureBox();
            this.end = new System.Windows.Forms.Button();
            this.green81 = new System.Windows.Forms.PictureBox();
            this.green71 = new System.Windows.Forms.PictureBox();
            this.green61 = new System.Windows.Forms.PictureBox();
            this.green51 = new System.Windows.Forms.PictureBox();
            this.black81 = new System.Windows.Forms.PictureBox();
            this.black71 = new System.Windows.Forms.PictureBox();
            this.black61 = new System.Windows.Forms.PictureBox();
            this.black51 = new System.Windows.Forms.PictureBox();
            this.green82 = new System.Windows.Forms.PictureBox();
            this.green72 = new System.Windows.Forms.PictureBox();
            this.green62 = new System.Windows.Forms.PictureBox();
            this.green52 = new System.Windows.Forms.PictureBox();
            this.green42 = new System.Windows.Forms.PictureBox();
            this.green32 = new System.Windows.Forms.PictureBox();
            this.green22 = new System.Windows.Forms.PictureBox();
            this.green12 = new System.Windows.Forms.PictureBox();
            this.black82 = new System.Windows.Forms.PictureBox();
            this.black72 = new System.Windows.Forms.PictureBox();
            this.black62 = new System.Windows.Forms.PictureBox();
            this.black52 = new System.Windows.Forms.PictureBox();
            this.black42 = new System.Windows.Forms.PictureBox();
            this.black32 = new System.Windows.Forms.PictureBox();
            this.black22 = new System.Windows.Forms.PictureBox();
            this.black12 = new System.Windows.Forms.PictureBox();
            this.green83 = new System.Windows.Forms.PictureBox();
            this.green73 = new System.Windows.Forms.PictureBox();
            this.green63 = new System.Windows.Forms.PictureBox();
            this.green53 = new System.Windows.Forms.PictureBox();
            this.green43 = new System.Windows.Forms.PictureBox();
            this.green33 = new System.Windows.Forms.PictureBox();
            this.green23 = new System.Windows.Forms.PictureBox();
            this.green13 = new System.Windows.Forms.PictureBox();
            this.black83 = new System.Windows.Forms.PictureBox();
            this.black73 = new System.Windows.Forms.PictureBox();
            this.black63 = new System.Windows.Forms.PictureBox();
            this.black53 = new System.Windows.Forms.PictureBox();
            this.black43 = new System.Windows.Forms.PictureBox();
            this.black33 = new System.Windows.Forms.PictureBox();
            this.black23 = new System.Windows.Forms.PictureBox();
            this.black13 = new System.Windows.Forms.PictureBox();
            this.green84 = new System.Windows.Forms.PictureBox();
            this.green74 = new System.Windows.Forms.PictureBox();
            this.green64 = new System.Windows.Forms.PictureBox();
            this.green54 = new System.Windows.Forms.PictureBox();
            this.green44 = new System.Windows.Forms.PictureBox();
            this.green34 = new System.Windows.Forms.PictureBox();
            this.green24 = new System.Windows.Forms.PictureBox();
            this.green14 = new System.Windows.Forms.PictureBox();
            this.black84 = new System.Windows.Forms.PictureBox();
            this.black74 = new System.Windows.Forms.PictureBox();
            this.black64 = new System.Windows.Forms.PictureBox();
            this.black54 = new System.Windows.Forms.PictureBox();
            this.black44 = new System.Windows.Forms.PictureBox();
            this.black34 = new System.Windows.Forms.PictureBox();
            this.black24 = new System.Windows.Forms.PictureBox();
            this.black14 = new System.Windows.Forms.PictureBox();
            this.green85 = new System.Windows.Forms.PictureBox();
            this.green75 = new System.Windows.Forms.PictureBox();
            this.green65 = new System.Windows.Forms.PictureBox();
            this.green55 = new System.Windows.Forms.PictureBox();
            this.green45 = new System.Windows.Forms.PictureBox();
            this.green35 = new System.Windows.Forms.PictureBox();
            this.green25 = new System.Windows.Forms.PictureBox();
            this.green15 = new System.Windows.Forms.PictureBox();
            this.black85 = new System.Windows.Forms.PictureBox();
            this.black75 = new System.Windows.Forms.PictureBox();
            this.black65 = new System.Windows.Forms.PictureBox();
            this.black55 = new System.Windows.Forms.PictureBox();
            this.black45 = new System.Windows.Forms.PictureBox();
            this.black35 = new System.Windows.Forms.PictureBox();
            this.black25 = new System.Windows.Forms.PictureBox();
            this.black15 = new System.Windows.Forms.PictureBox();
            this.green86 = new System.Windows.Forms.PictureBox();
            this.green76 = new System.Windows.Forms.PictureBox();
            this.green66 = new System.Windows.Forms.PictureBox();
            this.green56 = new System.Windows.Forms.PictureBox();
            this.green46 = new System.Windows.Forms.PictureBox();
            this.green36 = new System.Windows.Forms.PictureBox();
            this.green26 = new System.Windows.Forms.PictureBox();
            this.green16 = new System.Windows.Forms.PictureBox();
            this.black86 = new System.Windows.Forms.PictureBox();
            this.black76 = new System.Windows.Forms.PictureBox();
            this.black66 = new System.Windows.Forms.PictureBox();
            this.black56 = new System.Windows.Forms.PictureBox();
            this.black46 = new System.Windows.Forms.PictureBox();
            this.black36 = new System.Windows.Forms.PictureBox();
            this.black26 = new System.Windows.Forms.PictureBox();
            this.black16 = new System.Windows.Forms.PictureBox();
            this.green87 = new System.Windows.Forms.PictureBox();
            this.green77 = new System.Windows.Forms.PictureBox();
            this.green67 = new System.Windows.Forms.PictureBox();
            this.green57 = new System.Windows.Forms.PictureBox();
            this.green47 = new System.Windows.Forms.PictureBox();
            this.green37 = new System.Windows.Forms.PictureBox();
            this.green27 = new System.Windows.Forms.PictureBox();
            this.green17 = new System.Windows.Forms.PictureBox();
            this.black87 = new System.Windows.Forms.PictureBox();
            this.black77 = new System.Windows.Forms.PictureBox();
            this.black67 = new System.Windows.Forms.PictureBox();
            this.black57 = new System.Windows.Forms.PictureBox();
            this.black47 = new System.Windows.Forms.PictureBox();
            this.black37 = new System.Windows.Forms.PictureBox();
            this.black27 = new System.Windows.Forms.PictureBox();
            this.black17 = new System.Windows.Forms.PictureBox();
            this.green88 = new System.Windows.Forms.PictureBox();
            this.green78 = new System.Windows.Forms.PictureBox();
            this.green68 = new System.Windows.Forms.PictureBox();
            this.green58 = new System.Windows.Forms.PictureBox();
            this.green48 = new System.Windows.Forms.PictureBox();
            this.green38 = new System.Windows.Forms.PictureBox();
            this.green28 = new System.Windows.Forms.PictureBox();
            this.green18 = new System.Windows.Forms.PictureBox();
            this.black88 = new System.Windows.Forms.PictureBox();
            this.black78 = new System.Windows.Forms.PictureBox();
            this.black68 = new System.Windows.Forms.PictureBox();
            this.black58 = new System.Windows.Forms.PictureBox();
            this.black48 = new System.Windows.Forms.PictureBox();
            this.black38 = new System.Windows.Forms.PictureBox();
            this.black28 = new System.Windows.Forms.PictureBox();
            this.black18 = new System.Windows.Forms.PictureBox();
            this.reset = new System.Windows.Forms.Button();
            this.helpbutton = new System.Windows.Forms.Button();
            this.Aitimer = new System.Windows.Forms.Timer(this.components);
            this.player1count = new System.Windows.Forms.ListBox();
            this.player2count = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.Filename = new System.Windows.Forms.TextBox();
            this.load = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.player1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1select)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2select)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.black18)).BeginInit();
            this.SuspendLayout();
            // 
            // player1
            // 
            this.player1.Image = ((System.Drawing.Image)(resources.GetObject("player1.Image")));
            this.player1.Location = new System.Drawing.Point(80, 726);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(188, 67);
            this.player1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player1.TabIndex = 0;
            this.player1.TabStop = false;
            // 
            // player2
            // 
            this.player2.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.player2.Image = ((System.Drawing.Image)(resources.GetObject("player2.Image")));
            this.player2.Location = new System.Drawing.Point(512, 698);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(188, 110);
            this.player2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.player2.TabIndex = 1;
            this.player2.TabStop = false;
            // 
            // player1select
            // 
            this.player1select.Image = ((System.Drawing.Image)(resources.GetObject("player1select.Image")));
            this.player1select.Location = new System.Drawing.Point(80, 726);
            this.player1select.Name = "player1select";
            this.player1select.Size = new System.Drawing.Size(188, 67);
            this.player1select.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player1select.TabIndex = 2;
            this.player1select.TabStop = false;
            // 
            // player2select
            // 
            this.player2select.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.player2select.Image = ((System.Drawing.Image)(resources.GetObject("player2select.Image")));
            this.player2select.Location = new System.Drawing.Point(512, 698);
            this.player2select.Name = "player2select";
            this.player2select.Size = new System.Drawing.Size(188, 110);
            this.player2select.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.player2select.TabIndex = 3;
            this.player2select.TabStop = false;
            // 
            // background
            // 
            this.background.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("background.BackgroundImage")));
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(-3, -3);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(887, 683);
            this.background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background.TabIndex = 5;
            this.background.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(287, 698);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(93, 106);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(722, 698);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(99, 110);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // green11
            // 
            this.green11.Image = ((System.Drawing.Image)(resources.GetObject("green11.Image")));
            this.green11.Location = new System.Drawing.Point(28, 24);
            this.green11.Name = "green11";
            this.green11.Size = new System.Drawing.Size(78, 60);
            this.green11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green11.TabIndex = 11;
            this.green11.TabStop = false;
            this.green11.Click += new System.EventHandler(this.green11_Click);
            // 
            // black11
            // 
            this.black11.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black11.Image = global::Othello.Properties.Resources.black;
            this.black11.Location = new System.Drawing.Point(28, 24);
            this.black11.Name = "black11";
            this.black11.Size = new System.Drawing.Size(78, 60);
            this.black11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black11.TabIndex = 12;
            this.black11.TabStop = false;
            this.black11.Click += new System.EventHandler(this.green11_Click);
            // 
            // green41
            // 
            this.green41.Image = ((System.Drawing.Image)(resources.GetObject("green41.Image")));
            this.green41.Location = new System.Drawing.Point(28, 269);
            this.green41.Name = "green41";
            this.green41.Size = new System.Drawing.Size(78, 60);
            this.green41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green41.TabIndex = 13;
            this.green41.TabStop = false;
            this.green41.Click += new System.EventHandler(this.green41_Click);
            // 
            // green31
            // 
            this.green31.Image = ((System.Drawing.Image)(resources.GetObject("green31.Image")));
            this.green31.Location = new System.Drawing.Point(28, 188);
            this.green31.Name = "green31";
            this.green31.Size = new System.Drawing.Size(78, 60);
            this.green31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green31.TabIndex = 14;
            this.green31.TabStop = false;
            this.green31.Click += new System.EventHandler(this.green31_Click);
            // 
            // green21
            // 
            this.green21.Image = ((System.Drawing.Image)(resources.GetObject("green21.Image")));
            this.green21.Location = new System.Drawing.Point(28, 104);
            this.green21.Name = "green21";
            this.green21.Size = new System.Drawing.Size(78, 60);
            this.green21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green21.TabIndex = 15;
            this.green21.TabStop = false;
            this.green21.Click += new System.EventHandler(this.green21_Click);
            // 
            // black31
            // 
            this.black31.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black31.BackgroundImage")));
            this.black31.Image = ((System.Drawing.Image)(resources.GetObject("black31.Image")));
            this.black31.Location = new System.Drawing.Point(29, 188);
            this.black31.Name = "black31";
            this.black31.Size = new System.Drawing.Size(78, 60);
            this.black31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black31.TabIndex = 16;
            this.black31.TabStop = false;
            this.black31.Click += new System.EventHandler(this.green31_Click);
            // 
            // black21
            // 
            this.black21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black21.BackgroundImage")));
            this.black21.Image = global::Othello.Properties.Resources.black;
            this.black21.Location = new System.Drawing.Point(30, 104);
            this.black21.Name = "black21";
            this.black21.Size = new System.Drawing.Size(78, 60);
            this.black21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black21.TabIndex = 17;
            this.black21.TabStop = false;
            this.black21.Click += new System.EventHandler(this.green21_Click);
            // 
            // black41
            // 
            this.black41.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black41.BackgroundImage")));
            this.black41.Image = ((System.Drawing.Image)(resources.GetObject("black41.Image")));
            this.black41.Location = new System.Drawing.Point(30, 269);
            this.black41.Name = "black41";
            this.black41.Size = new System.Drawing.Size(78, 60);
            this.black41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black41.TabIndex = 18;
            this.black41.TabStop = false;
            this.black41.Click += new System.EventHandler(this.green41_Click);
            // 
            // end
            // 
            this.end.Location = new System.Drawing.Point(401, 710);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(75, 23);
            this.end.TabIndex = 23;
            this.end.Text = "I can\'t go";
            this.end.UseVisualStyleBackColor = true;
            this.end.Click += new System.EventHandler(this.end_Click);
            // 
            // green81
            // 
            this.green81.Image = ((System.Drawing.Image)(resources.GetObject("green81.Image")));
            this.green81.Location = new System.Drawing.Point(33, 598);
            this.green81.Name = "green81";
            this.green81.Size = new System.Drawing.Size(78, 60);
            this.green81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green81.TabIndex = 24;
            this.green81.TabStop = false;
            this.green81.Click += new System.EventHandler(this.green81_Click);
            // 
            // green71
            // 
            this.green71.Image = ((System.Drawing.Image)(resources.GetObject("green71.Image")));
            this.green71.Location = new System.Drawing.Point(30, 518);
            this.green71.Name = "green71";
            this.green71.Size = new System.Drawing.Size(78, 60);
            this.green71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green71.TabIndex = 25;
            this.green71.TabStop = false;
            this.green71.Click += new System.EventHandler(this.green71_Click);
            // 
            // green61
            // 
            this.green61.Image = ((System.Drawing.Image)(resources.GetObject("green61.Image")));
            this.green61.Location = new System.Drawing.Point(29, 436);
            this.green61.Name = "green61";
            this.green61.Size = new System.Drawing.Size(78, 60);
            this.green61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green61.TabIndex = 26;
            this.green61.TabStop = false;
            this.green61.Click += new System.EventHandler(this.green61_Click);
            // 
            // green51
            // 
            this.green51.Image = ((System.Drawing.Image)(resources.GetObject("green51.Image")));
            this.green51.Location = new System.Drawing.Point(30, 352);
            this.green51.Name = "green51";
            this.green51.Size = new System.Drawing.Size(78, 60);
            this.green51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green51.TabIndex = 27;
            this.green51.TabStop = false;
            this.green51.Click += new System.EventHandler(this.green51_Click);
            // 
            // black81
            // 
            this.black81.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black81.BackgroundImage")));
            this.black81.Image = ((System.Drawing.Image)(resources.GetObject("black81.Image")));
            this.black81.Location = new System.Drawing.Point(33, 598);
            this.black81.Name = "black81";
            this.black81.Size = new System.Drawing.Size(78, 60);
            this.black81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black81.TabIndex = 28;
            this.black81.TabStop = false;
            this.black81.Click += new System.EventHandler(this.green81_Click);
            // 
            // black71
            // 
            this.black71.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black71.BackgroundImage")));
            this.black71.Image = ((System.Drawing.Image)(resources.GetObject("black71.Image")));
            this.black71.Location = new System.Drawing.Point(33, 518);
            this.black71.Name = "black71";
            this.black71.Size = new System.Drawing.Size(78, 60);
            this.black71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black71.TabIndex = 29;
            this.black71.TabStop = false;
            this.black71.Click += new System.EventHandler(this.green71_Click);
            // 
            // black61
            // 
            this.black61.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black61.BackgroundImage")));
            this.black61.Image = ((System.Drawing.Image)(resources.GetObject("black61.Image")));
            this.black61.Location = new System.Drawing.Point(32, 436);
            this.black61.Name = "black61";
            this.black61.Size = new System.Drawing.Size(78, 60);
            this.black61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black61.TabIndex = 30;
            this.black61.TabStop = false;
            this.black61.Click += new System.EventHandler(this.green61_Click);
            // 
            // black51
            // 
            this.black51.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black51.BackgroundImage")));
            this.black51.Image = ((System.Drawing.Image)(resources.GetObject("black51.Image")));
            this.black51.Location = new System.Drawing.Point(31, 352);
            this.black51.Name = "black51";
            this.black51.Size = new System.Drawing.Size(78, 60);
            this.black51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black51.TabIndex = 31;
            this.black51.TabStop = false;
            this.black51.Click += new System.EventHandler(this.green51_Click);
            // 
            // green82
            // 
            this.green82.Image = ((System.Drawing.Image)(resources.GetObject("green82.Image")));
            this.green82.Location = new System.Drawing.Point(135, 598);
            this.green82.Name = "green82";
            this.green82.Size = new System.Drawing.Size(78, 60);
            this.green82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green82.TabIndex = 35;
            this.green82.TabStop = false;
            this.green82.Click += new System.EventHandler(this.green82_Click);
            // 
            // green72
            // 
            this.green72.Image = ((System.Drawing.Image)(resources.GetObject("green72.Image")));
            this.green72.Location = new System.Drawing.Point(135, 518);
            this.green72.Name = "green72";
            this.green72.Size = new System.Drawing.Size(78, 60);
            this.green72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green72.TabIndex = 36;
            this.green72.TabStop = false;
            this.green72.Click += new System.EventHandler(this.green72_Click);
            // 
            // green62
            // 
            this.green62.Image = ((System.Drawing.Image)(resources.GetObject("green62.Image")));
            this.green62.Location = new System.Drawing.Point(135, 436);
            this.green62.Name = "green62";
            this.green62.Size = new System.Drawing.Size(78, 60);
            this.green62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green62.TabIndex = 37;
            this.green62.TabStop = false;
            this.green62.Click += new System.EventHandler(this.green62_Click);
            // 
            // green52
            // 
            this.green52.Image = ((System.Drawing.Image)(resources.GetObject("green52.Image")));
            this.green52.Location = new System.Drawing.Point(135, 352);
            this.green52.Name = "green52";
            this.green52.Size = new System.Drawing.Size(78, 60);
            this.green52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green52.TabIndex = 38;
            this.green52.TabStop = false;
            this.green52.Click += new System.EventHandler(this.green52_Click);
            // 
            // green42
            // 
            this.green42.Image = ((System.Drawing.Image)(resources.GetObject("green42.Image")));
            this.green42.Location = new System.Drawing.Point(135, 269);
            this.green42.Name = "green42";
            this.green42.Size = new System.Drawing.Size(78, 60);
            this.green42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green42.TabIndex = 39;
            this.green42.TabStop = false;
            this.green42.Click += new System.EventHandler(this.green42_Click);
            // 
            // green32
            // 
            this.green32.Image = ((System.Drawing.Image)(resources.GetObject("green32.Image")));
            this.green32.Location = new System.Drawing.Point(135, 188);
            this.green32.Name = "green32";
            this.green32.Size = new System.Drawing.Size(78, 60);
            this.green32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green32.TabIndex = 40;
            this.green32.TabStop = false;
            this.green32.Click += new System.EventHandler(this.green32_Click);
            // 
            // green22
            // 
            this.green22.Image = ((System.Drawing.Image)(resources.GetObject("green22.Image")));
            this.green22.Location = new System.Drawing.Point(135, 104);
            this.green22.Name = "green22";
            this.green22.Size = new System.Drawing.Size(78, 60);
            this.green22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green22.TabIndex = 41;
            this.green22.TabStop = false;
            this.green22.Click += new System.EventHandler(this.green22_Click);
            // 
            // green12
            // 
            this.green12.Image = ((System.Drawing.Image)(resources.GetObject("green12.Image")));
            this.green12.Location = new System.Drawing.Point(135, 24);
            this.green12.Name = "green12";
            this.green12.Size = new System.Drawing.Size(78, 60);
            this.green12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green12.TabIndex = 42;
            this.green12.TabStop = false;
            this.green12.Click += new System.EventHandler(this.green12_Click);
            // 
            // black82
            // 
            this.black82.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black82.BackgroundImage")));
            this.black82.Image = ((System.Drawing.Image)(resources.GetObject("black82.Image")));
            this.black82.Location = new System.Drawing.Point(135, 598);
            this.black82.Name = "black82";
            this.black82.Size = new System.Drawing.Size(78, 60);
            this.black82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black82.TabIndex = 43;
            this.black82.TabStop = false;
            this.black82.Click += new System.EventHandler(this.green82_Click);
            // 
            // black72
            // 
            this.black72.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black72.BackgroundImage")));
            this.black72.Image = ((System.Drawing.Image)(resources.GetObject("black72.Image")));
            this.black72.Location = new System.Drawing.Point(135, 518);
            this.black72.Name = "black72";
            this.black72.Size = new System.Drawing.Size(78, 60);
            this.black72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black72.TabIndex = 44;
            this.black72.TabStop = false;
            this.black72.Click += new System.EventHandler(this.green72_Click);
            // 
            // black62
            // 
            this.black62.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black62.BackgroundImage")));
            this.black62.Image = ((System.Drawing.Image)(resources.GetObject("black62.Image")));
            this.black62.Location = new System.Drawing.Point(135, 436);
            this.black62.Name = "black62";
            this.black62.Size = new System.Drawing.Size(78, 60);
            this.black62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black62.TabIndex = 45;
            this.black62.TabStop = false;
            this.black62.Click += new System.EventHandler(this.green62_Click);
            // 
            // black52
            // 
            this.black52.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black52.BackgroundImage")));
            this.black52.Image = ((System.Drawing.Image)(resources.GetObject("black52.Image")));
            this.black52.Location = new System.Drawing.Point(135, 352);
            this.black52.Name = "black52";
            this.black52.Size = new System.Drawing.Size(78, 60);
            this.black52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black52.TabIndex = 46;
            this.black52.TabStop = false;
            this.black52.Click += new System.EventHandler(this.green52_Click);
            // 
            // black42
            // 
            this.black42.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black42.BackgroundImage")));
            this.black42.Image = ((System.Drawing.Image)(resources.GetObject("black42.Image")));
            this.black42.Location = new System.Drawing.Point(135, 269);
            this.black42.Name = "black42";
            this.black42.Size = new System.Drawing.Size(78, 60);
            this.black42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black42.TabIndex = 47;
            this.black42.TabStop = false;
            this.black42.Click += new System.EventHandler(this.green42_Click);
            // 
            // black32
            // 
            this.black32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black32.BackgroundImage")));
            this.black32.Image = ((System.Drawing.Image)(resources.GetObject("black32.Image")));
            this.black32.Location = new System.Drawing.Point(135, 188);
            this.black32.Name = "black32";
            this.black32.Size = new System.Drawing.Size(78, 60);
            this.black32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black32.TabIndex = 48;
            this.black32.TabStop = false;
            this.black32.Click += new System.EventHandler(this.green32_Click);
            // 
            // black22
            // 
            this.black22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black22.BackgroundImage")));
            this.black22.Image = global::Othello.Properties.Resources.black;
            this.black22.Location = new System.Drawing.Point(135, 104);
            this.black22.Name = "black22";
            this.black22.Size = new System.Drawing.Size(78, 60);
            this.black22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black22.TabIndex = 49;
            this.black22.TabStop = false;
            this.black22.Click += new System.EventHandler(this.green22_Click);
            // 
            // black12
            // 
            this.black12.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black12.Image = global::Othello.Properties.Resources.black;
            this.black12.Location = new System.Drawing.Point(136, 24);
            this.black12.Name = "black12";
            this.black12.Size = new System.Drawing.Size(78, 60);
            this.black12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black12.TabIndex = 50;
            this.black12.TabStop = false;
            this.black12.Click += new System.EventHandler(this.green12_Click);
            // 
            // green83
            // 
            this.green83.Image = ((System.Drawing.Image)(resources.GetObject("green83.Image")));
            this.green83.Location = new System.Drawing.Point(245, 598);
            this.green83.Name = "green83";
            this.green83.Size = new System.Drawing.Size(78, 60);
            this.green83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green83.TabIndex = 59;
            this.green83.TabStop = false;
            this.green83.Click += new System.EventHandler(this.green83_Click);
            // 
            // green73
            // 
            this.green73.Image = ((System.Drawing.Image)(resources.GetObject("green73.Image")));
            this.green73.Location = new System.Drawing.Point(245, 518);
            this.green73.Name = "green73";
            this.green73.Size = new System.Drawing.Size(78, 60);
            this.green73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green73.TabIndex = 60;
            this.green73.TabStop = false;
            this.green73.Click += new System.EventHandler(this.green73_Click);
            // 
            // green63
            // 
            this.green63.Image = ((System.Drawing.Image)(resources.GetObject("green63.Image")));
            this.green63.Location = new System.Drawing.Point(245, 436);
            this.green63.Name = "green63";
            this.green63.Size = new System.Drawing.Size(78, 60);
            this.green63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green63.TabIndex = 61;
            this.green63.TabStop = false;
            this.green63.Click += new System.EventHandler(this.green63_Click);
            // 
            // green53
            // 
            this.green53.Image = ((System.Drawing.Image)(resources.GetObject("green53.Image")));
            this.green53.Location = new System.Drawing.Point(245, 352);
            this.green53.Name = "green53";
            this.green53.Size = new System.Drawing.Size(78, 60);
            this.green53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green53.TabIndex = 62;
            this.green53.TabStop = false;
            this.green53.Click += new System.EventHandler(this.green53_Click);
            // 
            // green43
            // 
            this.green43.Image = ((System.Drawing.Image)(resources.GetObject("green43.Image")));
            this.green43.Location = new System.Drawing.Point(245, 269);
            this.green43.Name = "green43";
            this.green43.Size = new System.Drawing.Size(78, 60);
            this.green43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green43.TabIndex = 63;
            this.green43.TabStop = false;
            this.green43.Click += new System.EventHandler(this.green43_Click);
            // 
            // green33
            // 
            this.green33.Image = ((System.Drawing.Image)(resources.GetObject("green33.Image")));
            this.green33.Location = new System.Drawing.Point(245, 188);
            this.green33.Name = "green33";
            this.green33.Size = new System.Drawing.Size(78, 60);
            this.green33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green33.TabIndex = 64;
            this.green33.TabStop = false;
            this.green33.Click += new System.EventHandler(this.green33_Click);
            // 
            // green23
            // 
            this.green23.Image = ((System.Drawing.Image)(resources.GetObject("green23.Image")));
            this.green23.Location = new System.Drawing.Point(245, 104);
            this.green23.Name = "green23";
            this.green23.Size = new System.Drawing.Size(78, 60);
            this.green23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green23.TabIndex = 65;
            this.green23.TabStop = false;
            this.green23.Click += new System.EventHandler(this.green23_Click);
            // 
            // green13
            // 
            this.green13.Image = ((System.Drawing.Image)(resources.GetObject("green13.Image")));
            this.green13.Location = new System.Drawing.Point(245, 24);
            this.green13.Name = "green13";
            this.green13.Size = new System.Drawing.Size(78, 60);
            this.green13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green13.TabIndex = 66;
            this.green13.TabStop = false;
            this.green13.Click += new System.EventHandler(this.green13_Click);
            // 
            // black83
            // 
            this.black83.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black83.BackgroundImage")));
            this.black83.Image = ((System.Drawing.Image)(resources.GetObject("black83.Image")));
            this.black83.Location = new System.Drawing.Point(246, 598);
            this.black83.Name = "black83";
            this.black83.Size = new System.Drawing.Size(78, 60);
            this.black83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black83.TabIndex = 67;
            this.black83.TabStop = false;
            this.black83.Click += new System.EventHandler(this.green83_Click);
            // 
            // black73
            // 
            this.black73.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black73.BackgroundImage")));
            this.black73.Image = ((System.Drawing.Image)(resources.GetObject("black73.Image")));
            this.black73.Location = new System.Drawing.Point(243, 518);
            this.black73.Name = "black73";
            this.black73.Size = new System.Drawing.Size(78, 60);
            this.black73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black73.TabIndex = 68;
            this.black73.TabStop = false;
            this.black73.Click += new System.EventHandler(this.green73_Click);
            // 
            // black63
            // 
            this.black63.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black63.BackgroundImage")));
            this.black63.Image = ((System.Drawing.Image)(resources.GetObject("black63.Image")));
            this.black63.Location = new System.Drawing.Point(243, 436);
            this.black63.Name = "black63";
            this.black63.Size = new System.Drawing.Size(78, 60);
            this.black63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black63.TabIndex = 69;
            this.black63.TabStop = false;
            this.black63.Click += new System.EventHandler(this.green63_Click);
            // 
            // black53
            // 
            this.black53.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black53.BackgroundImage")));
            this.black53.Image = ((System.Drawing.Image)(resources.GetObject("black53.Image")));
            this.black53.Location = new System.Drawing.Point(245, 352);
            this.black53.Name = "black53";
            this.black53.Size = new System.Drawing.Size(78, 60);
            this.black53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black53.TabIndex = 70;
            this.black53.TabStop = false;
            this.black53.Click += new System.EventHandler(this.green53_Click);
            // 
            // black43
            // 
            this.black43.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black43.BackgroundImage")));
            this.black43.Image = ((System.Drawing.Image)(resources.GetObject("black43.Image")));
            this.black43.Location = new System.Drawing.Point(244, 269);
            this.black43.Name = "black43";
            this.black43.Size = new System.Drawing.Size(78, 60);
            this.black43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black43.TabIndex = 71;
            this.black43.TabStop = false;
            this.black43.Click += new System.EventHandler(this.green43_Click);
            // 
            // black33
            // 
            this.black33.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black33.BackgroundImage")));
            this.black33.Image = ((System.Drawing.Image)(resources.GetObject("black33.Image")));
            this.black33.Location = new System.Drawing.Point(245, 188);
            this.black33.Name = "black33";
            this.black33.Size = new System.Drawing.Size(78, 60);
            this.black33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black33.TabIndex = 72;
            this.black33.TabStop = false;
            this.black33.Click += new System.EventHandler(this.green33_Click);
            // 
            // black23
            // 
            this.black23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black23.BackgroundImage")));
            this.black23.Image = global::Othello.Properties.Resources.black;
            this.black23.Location = new System.Drawing.Point(245, 104);
            this.black23.Name = "black23";
            this.black23.Size = new System.Drawing.Size(78, 60);
            this.black23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black23.TabIndex = 73;
            this.black23.TabStop = false;
            this.black23.Click += new System.EventHandler(this.green23_Click);
            // 
            // black13
            // 
            this.black13.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black13.Image = global::Othello.Properties.Resources.black;
            this.black13.Location = new System.Drawing.Point(243, 24);
            this.black13.Name = "black13";
            this.black13.Size = new System.Drawing.Size(78, 60);
            this.black13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black13.TabIndex = 74;
            this.black13.TabStop = false;
            this.black13.Click += new System.EventHandler(this.green13_Click);
            // 
            // green84
            // 
            this.green84.Image = ((System.Drawing.Image)(resources.GetObject("green84.Image")));
            this.green84.Location = new System.Drawing.Point(351, 598);
            this.green84.Name = "green84";
            this.green84.Size = new System.Drawing.Size(78, 60);
            this.green84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green84.TabIndex = 83;
            this.green84.TabStop = false;
            this.green84.Click += new System.EventHandler(this.green84_Click);
            // 
            // green74
            // 
            this.green74.Image = ((System.Drawing.Image)(resources.GetObject("green74.Image")));
            this.green74.Location = new System.Drawing.Point(351, 518);
            this.green74.Name = "green74";
            this.green74.Size = new System.Drawing.Size(78, 60);
            this.green74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green74.TabIndex = 84;
            this.green74.TabStop = false;
            this.green74.Click += new System.EventHandler(this.green74_Click);
            // 
            // green64
            // 
            this.green64.Image = ((System.Drawing.Image)(resources.GetObject("green64.Image")));
            this.green64.Location = new System.Drawing.Point(351, 436);
            this.green64.Name = "green64";
            this.green64.Size = new System.Drawing.Size(78, 60);
            this.green64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green64.TabIndex = 85;
            this.green64.TabStop = false;
            this.green64.Click += new System.EventHandler(this.green64_Click);
            // 
            // green54
            // 
            this.green54.Image = ((System.Drawing.Image)(resources.GetObject("green54.Image")));
            this.green54.Location = new System.Drawing.Point(351, 352);
            this.green54.Name = "green54";
            this.green54.Size = new System.Drawing.Size(78, 60);
            this.green54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green54.TabIndex = 86;
            this.green54.TabStop = false;
            this.green54.Click += new System.EventHandler(this.green54_Click);
            // 
            // green44
            // 
            this.green44.Image = ((System.Drawing.Image)(resources.GetObject("green44.Image")));
            this.green44.Location = new System.Drawing.Point(351, 269);
            this.green44.Name = "green44";
            this.green44.Size = new System.Drawing.Size(78, 60);
            this.green44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green44.TabIndex = 87;
            this.green44.TabStop = false;
            this.green44.Click += new System.EventHandler(this.green44_Click);
            // 
            // green34
            // 
            this.green34.Image = ((System.Drawing.Image)(resources.GetObject("green34.Image")));
            this.green34.Location = new System.Drawing.Point(351, 188);
            this.green34.Name = "green34";
            this.green34.Size = new System.Drawing.Size(78, 60);
            this.green34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green34.TabIndex = 88;
            this.green34.TabStop = false;
            this.green34.Click += new System.EventHandler(this.green34_Click);
            // 
            // green24
            // 
            this.green24.Image = ((System.Drawing.Image)(resources.GetObject("green24.Image")));
            this.green24.Location = new System.Drawing.Point(351, 104);
            this.green24.Name = "green24";
            this.green24.Size = new System.Drawing.Size(78, 60);
            this.green24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green24.TabIndex = 89;
            this.green24.TabStop = false;
            this.green24.Click += new System.EventHandler(this.green24_Click);
            // 
            // green14
            // 
            this.green14.Image = ((System.Drawing.Image)(resources.GetObject("green14.Image")));
            this.green14.Location = new System.Drawing.Point(351, 24);
            this.green14.Name = "green14";
            this.green14.Size = new System.Drawing.Size(78, 60);
            this.green14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green14.TabIndex = 90;
            this.green14.TabStop = false;
            this.green14.Click += new System.EventHandler(this.green14_Click);
            // 
            // black84
            // 
            this.black84.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black84.BackgroundImage")));
            this.black84.Image = ((System.Drawing.Image)(resources.GetObject("black84.Image")));
            this.black84.Location = new System.Drawing.Point(353, 598);
            this.black84.Name = "black84";
            this.black84.Size = new System.Drawing.Size(78, 60);
            this.black84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black84.TabIndex = 92;
            this.black84.TabStop = false;
            this.black84.Click += new System.EventHandler(this.green84_Click);
            // 
            // black74
            // 
            this.black74.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black74.BackgroundImage")));
            this.black74.Image = ((System.Drawing.Image)(resources.GetObject("black74.Image")));
            this.black74.Location = new System.Drawing.Point(350, 518);
            this.black74.Name = "black74";
            this.black74.Size = new System.Drawing.Size(78, 60);
            this.black74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black74.TabIndex = 93;
            this.black74.TabStop = false;
            this.black74.Click += new System.EventHandler(this.green74_Click);
            // 
            // black64
            // 
            this.black64.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black64.BackgroundImage")));
            this.black64.Image = ((System.Drawing.Image)(resources.GetObject("black64.Image")));
            this.black64.Location = new System.Drawing.Point(350, 436);
            this.black64.Name = "black64";
            this.black64.Size = new System.Drawing.Size(78, 60);
            this.black64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black64.TabIndex = 94;
            this.black64.TabStop = false;
            this.black64.Click += new System.EventHandler(this.green64_Click);
            // 
            // black54
            // 
            this.black54.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black54.BackgroundImage")));
            this.black54.Image = ((System.Drawing.Image)(resources.GetObject("black54.Image")));
            this.black54.Location = new System.Drawing.Point(351, 352);
            this.black54.Name = "black54";
            this.black54.Size = new System.Drawing.Size(78, 60);
            this.black54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black54.TabIndex = 95;
            this.black54.TabStop = false;
            this.black54.Click += new System.EventHandler(this.green54_Click);
            // 
            // black44
            // 
            this.black44.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black44.BackgroundImage")));
            this.black44.Image = ((System.Drawing.Image)(resources.GetObject("black44.Image")));
            this.black44.Location = new System.Drawing.Point(353, 269);
            this.black44.Name = "black44";
            this.black44.Size = new System.Drawing.Size(78, 60);
            this.black44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black44.TabIndex = 96;
            this.black44.TabStop = false;
            this.black44.Click += new System.EventHandler(this.green44_Click);
            // 
            // black34
            // 
            this.black34.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black34.BackgroundImage")));
            this.black34.Image = ((System.Drawing.Image)(resources.GetObject("black34.Image")));
            this.black34.Location = new System.Drawing.Point(352, 188);
            this.black34.Name = "black34";
            this.black34.Size = new System.Drawing.Size(78, 60);
            this.black34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black34.TabIndex = 97;
            this.black34.TabStop = false;
            this.black34.Click += new System.EventHandler(this.green34_Click);
            // 
            // black24
            // 
            this.black24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black24.BackgroundImage")));
            this.black24.Image = global::Othello.Properties.Resources.black;
            this.black24.Location = new System.Drawing.Point(352, 104);
            this.black24.Name = "black24";
            this.black24.Size = new System.Drawing.Size(78, 60);
            this.black24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black24.TabIndex = 98;
            this.black24.TabStop = false;
            this.black24.Click += new System.EventHandler(this.green24_Click);
            // 
            // black14
            // 
            this.black14.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black14.Image = global::Othello.Properties.Resources.black;
            this.black14.Location = new System.Drawing.Point(350, 24);
            this.black14.Name = "black14";
            this.black14.Size = new System.Drawing.Size(78, 60);
            this.black14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black14.TabIndex = 99;
            this.black14.TabStop = false;
            this.black14.Click += new System.EventHandler(this.green14_Click);
            // 
            // green85
            // 
            this.green85.Image = ((System.Drawing.Image)(resources.GetObject("green85.Image")));
            this.green85.Location = new System.Drawing.Point(457, 598);
            this.green85.Name = "green85";
            this.green85.Size = new System.Drawing.Size(78, 60);
            this.green85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green85.TabIndex = 108;
            this.green85.TabStop = false;
            this.green85.Click += new System.EventHandler(this.green85_Click);
            // 
            // green75
            // 
            this.green75.Image = ((System.Drawing.Image)(resources.GetObject("green75.Image")));
            this.green75.Location = new System.Drawing.Point(457, 518);
            this.green75.Name = "green75";
            this.green75.Size = new System.Drawing.Size(78, 60);
            this.green75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green75.TabIndex = 109;
            this.green75.TabStop = false;
            this.green75.Click += new System.EventHandler(this.green75_Click);
            // 
            // green65
            // 
            this.green65.Image = ((System.Drawing.Image)(resources.GetObject("green65.Image")));
            this.green65.Location = new System.Drawing.Point(457, 436);
            this.green65.Name = "green65";
            this.green65.Size = new System.Drawing.Size(78, 60);
            this.green65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green65.TabIndex = 110;
            this.green65.TabStop = false;
            this.green65.Click += new System.EventHandler(this.green65_Click);
            // 
            // green55
            // 
            this.green55.Image = ((System.Drawing.Image)(resources.GetObject("green55.Image")));
            this.green55.Location = new System.Drawing.Point(457, 352);
            this.green55.Name = "green55";
            this.green55.Size = new System.Drawing.Size(78, 60);
            this.green55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green55.TabIndex = 111;
            this.green55.TabStop = false;
            this.green55.Click += new System.EventHandler(this.green55_Click);
            // 
            // green45
            // 
            this.green45.Image = ((System.Drawing.Image)(resources.GetObject("green45.Image")));
            this.green45.Location = new System.Drawing.Point(457, 269);
            this.green45.Name = "green45";
            this.green45.Size = new System.Drawing.Size(78, 60);
            this.green45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green45.TabIndex = 112;
            this.green45.TabStop = false;
            this.green45.Click += new System.EventHandler(this.green45_Click);
            // 
            // green35
            // 
            this.green35.Image = ((System.Drawing.Image)(resources.GetObject("green35.Image")));
            this.green35.Location = new System.Drawing.Point(457, 188);
            this.green35.Name = "green35";
            this.green35.Size = new System.Drawing.Size(78, 60);
            this.green35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green35.TabIndex = 113;
            this.green35.TabStop = false;
            this.green35.Click += new System.EventHandler(this.green35_Click);
            // 
            // green25
            // 
            this.green25.Image = ((System.Drawing.Image)(resources.GetObject("green25.Image")));
            this.green25.Location = new System.Drawing.Point(457, 104);
            this.green25.Name = "green25";
            this.green25.Size = new System.Drawing.Size(78, 60);
            this.green25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green25.TabIndex = 114;
            this.green25.TabStop = false;
            this.green25.Click += new System.EventHandler(this.green25_Click);
            // 
            // green15
            // 
            this.green15.Image = ((System.Drawing.Image)(resources.GetObject("green15.Image")));
            this.green15.Location = new System.Drawing.Point(457, 24);
            this.green15.Name = "green15";
            this.green15.Size = new System.Drawing.Size(78, 60);
            this.green15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green15.TabIndex = 115;
            this.green15.TabStop = false;
            this.green15.Click += new System.EventHandler(this.green15_Click);
            // 
            // black85
            // 
            this.black85.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black85.BackgroundImage")));
            this.black85.Image = ((System.Drawing.Image)(resources.GetObject("black85.Image")));
            this.black85.Location = new System.Drawing.Point(459, 598);
            this.black85.Name = "black85";
            this.black85.Size = new System.Drawing.Size(78, 60);
            this.black85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black85.TabIndex = 116;
            this.black85.TabStop = false;
            this.black85.Click += new System.EventHandler(this.green85_Click);
            // 
            // black75
            // 
            this.black75.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black75.BackgroundImage")));
            this.black75.Image = ((System.Drawing.Image)(resources.GetObject("black75.Image")));
            this.black75.Location = new System.Drawing.Point(458, 518);
            this.black75.Name = "black75";
            this.black75.Size = new System.Drawing.Size(78, 60);
            this.black75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black75.TabIndex = 117;
            this.black75.TabStop = false;
            this.black75.Click += new System.EventHandler(this.green75_Click);
            // 
            // black65
            // 
            this.black65.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black65.BackgroundImage")));
            this.black65.Image = ((System.Drawing.Image)(resources.GetObject("black65.Image")));
            this.black65.Location = new System.Drawing.Point(458, 436);
            this.black65.Name = "black65";
            this.black65.Size = new System.Drawing.Size(78, 60);
            this.black65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black65.TabIndex = 118;
            this.black65.TabStop = false;
            this.black65.Click += new System.EventHandler(this.green65_Click);
            // 
            // black55
            // 
            this.black55.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black55.BackgroundImage")));
            this.black55.Image = ((System.Drawing.Image)(resources.GetObject("black55.Image")));
            this.black55.Location = new System.Drawing.Point(457, 352);
            this.black55.Name = "black55";
            this.black55.Size = new System.Drawing.Size(78, 60);
            this.black55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black55.TabIndex = 119;
            this.black55.TabStop = false;
            this.black55.Click += new System.EventHandler(this.green55_Click);
            // 
            // black45
            // 
            this.black45.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black45.BackgroundImage")));
            this.black45.Image = ((System.Drawing.Image)(resources.GetObject("black45.Image")));
            this.black45.Location = new System.Drawing.Point(457, 269);
            this.black45.Name = "black45";
            this.black45.Size = new System.Drawing.Size(78, 60);
            this.black45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black45.TabIndex = 120;
            this.black45.TabStop = false;
            this.black45.Click += new System.EventHandler(this.green45_Click);
            // 
            // black35
            // 
            this.black35.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black35.BackgroundImage")));
            this.black35.Image = ((System.Drawing.Image)(resources.GetObject("black35.Image")));
            this.black35.Location = new System.Drawing.Point(458, 188);
            this.black35.Name = "black35";
            this.black35.Size = new System.Drawing.Size(78, 60);
            this.black35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black35.TabIndex = 121;
            this.black35.TabStop = false;
            this.black35.Click += new System.EventHandler(this.green35_Click);
            // 
            // black25
            // 
            this.black25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black25.BackgroundImage")));
            this.black25.Image = global::Othello.Properties.Resources.black;
            this.black25.Location = new System.Drawing.Point(457, 104);
            this.black25.Name = "black25";
            this.black25.Size = new System.Drawing.Size(78, 60);
            this.black25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black25.TabIndex = 122;
            this.black25.TabStop = false;
            this.black25.Click += new System.EventHandler(this.green25_Click);
            // 
            // black15
            // 
            this.black15.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black15.Image = global::Othello.Properties.Resources.black;
            this.black15.Location = new System.Drawing.Point(458, 24);
            this.black15.Name = "black15";
            this.black15.Size = new System.Drawing.Size(78, 60);
            this.black15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black15.TabIndex = 123;
            this.black15.TabStop = false;
            this.black15.Click += new System.EventHandler(this.green15_Click);
            // 
            // green86
            // 
            this.green86.Image = ((System.Drawing.Image)(resources.GetObject("green86.Image")));
            this.green86.Location = new System.Drawing.Point(561, 598);
            this.green86.Name = "green86";
            this.green86.Size = new System.Drawing.Size(78, 60);
            this.green86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green86.TabIndex = 132;
            this.green86.TabStop = false;
            this.green86.Click += new System.EventHandler(this.green86_Click);
            // 
            // green76
            // 
            this.green76.Image = ((System.Drawing.Image)(resources.GetObject("green76.Image")));
            this.green76.Location = new System.Drawing.Point(561, 518);
            this.green76.Name = "green76";
            this.green76.Size = new System.Drawing.Size(78, 60);
            this.green76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green76.TabIndex = 133;
            this.green76.TabStop = false;
            this.green76.Click += new System.EventHandler(this.green76_Click);
            // 
            // green66
            // 
            this.green66.Image = ((System.Drawing.Image)(resources.GetObject("green66.Image")));
            this.green66.Location = new System.Drawing.Point(561, 436);
            this.green66.Name = "green66";
            this.green66.Size = new System.Drawing.Size(78, 60);
            this.green66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green66.TabIndex = 134;
            this.green66.TabStop = false;
            this.green66.Click += new System.EventHandler(this.green66_Click);
            // 
            // green56
            // 
            this.green56.Image = ((System.Drawing.Image)(resources.GetObject("green56.Image")));
            this.green56.Location = new System.Drawing.Point(561, 352);
            this.green56.Name = "green56";
            this.green56.Size = new System.Drawing.Size(78, 60);
            this.green56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green56.TabIndex = 135;
            this.green56.TabStop = false;
            this.green56.Click += new System.EventHandler(this.green56_Click);
            // 
            // green46
            // 
            this.green46.Image = ((System.Drawing.Image)(resources.GetObject("green46.Image")));
            this.green46.Location = new System.Drawing.Point(561, 269);
            this.green46.Name = "green46";
            this.green46.Size = new System.Drawing.Size(78, 60);
            this.green46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green46.TabIndex = 136;
            this.green46.TabStop = false;
            this.green46.Click += new System.EventHandler(this.green46_Click);
            // 
            // green36
            // 
            this.green36.Image = ((System.Drawing.Image)(resources.GetObject("green36.Image")));
            this.green36.Location = new System.Drawing.Point(561, 188);
            this.green36.Name = "green36";
            this.green36.Size = new System.Drawing.Size(78, 60);
            this.green36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green36.TabIndex = 137;
            this.green36.TabStop = false;
            this.green36.Click += new System.EventHandler(this.green36_Click);
            // 
            // green26
            // 
            this.green26.Image = ((System.Drawing.Image)(resources.GetObject("green26.Image")));
            this.green26.Location = new System.Drawing.Point(561, 104);
            this.green26.Name = "green26";
            this.green26.Size = new System.Drawing.Size(78, 60);
            this.green26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green26.TabIndex = 138;
            this.green26.TabStop = false;
            this.green26.Click += new System.EventHandler(this.green26_Click);
            // 
            // green16
            // 
            this.green16.Image = ((System.Drawing.Image)(resources.GetObject("green16.Image")));
            this.green16.Location = new System.Drawing.Point(561, 24);
            this.green16.Name = "green16";
            this.green16.Size = new System.Drawing.Size(78, 60);
            this.green16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green16.TabIndex = 139;
            this.green16.TabStop = false;
            this.green16.Click += new System.EventHandler(this.green16_Click);
            // 
            // black86
            // 
            this.black86.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black86.BackgroundImage")));
            this.black86.Image = ((System.Drawing.Image)(resources.GetObject("black86.Image")));
            this.black86.Location = new System.Drawing.Point(565, 598);
            this.black86.Name = "black86";
            this.black86.Size = new System.Drawing.Size(78, 60);
            this.black86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black86.TabIndex = 140;
            this.black86.TabStop = false;
            this.black86.Click += new System.EventHandler(this.green86_Click);
            // 
            // black76
            // 
            this.black76.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black76.BackgroundImage")));
            this.black76.Image = ((System.Drawing.Image)(resources.GetObject("black76.Image")));
            this.black76.Location = new System.Drawing.Point(564, 518);
            this.black76.Name = "black76";
            this.black76.Size = new System.Drawing.Size(78, 60);
            this.black76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black76.TabIndex = 141;
            this.black76.TabStop = false;
            this.black76.Click += new System.EventHandler(this.green76_Click);
            // 
            // black66
            // 
            this.black66.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black66.BackgroundImage")));
            this.black66.Image = ((System.Drawing.Image)(resources.GetObject("black66.Image")));
            this.black66.Location = new System.Drawing.Point(563, 436);
            this.black66.Name = "black66";
            this.black66.Size = new System.Drawing.Size(78, 60);
            this.black66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black66.TabIndex = 142;
            this.black66.TabStop = false;
            this.black66.Click += new System.EventHandler(this.green66_Click);
            // 
            // black56
            // 
            this.black56.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black56.BackgroundImage")));
            this.black56.Image = ((System.Drawing.Image)(resources.GetObject("black56.Image")));
            this.black56.Location = new System.Drawing.Point(563, 352);
            this.black56.Name = "black56";
            this.black56.Size = new System.Drawing.Size(78, 60);
            this.black56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black56.TabIndex = 143;
            this.black56.TabStop = false;
            this.black56.Click += new System.EventHandler(this.green56_Click);
            // 
            // black46
            // 
            this.black46.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black46.BackgroundImage")));
            this.black46.Image = ((System.Drawing.Image)(resources.GetObject("black46.Image")));
            this.black46.Location = new System.Drawing.Point(561, 269);
            this.black46.Name = "black46";
            this.black46.Size = new System.Drawing.Size(78, 60);
            this.black46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black46.TabIndex = 144;
            this.black46.TabStop = false;
            this.black46.Click += new System.EventHandler(this.green46_Click);
            // 
            // black36
            // 
            this.black36.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black36.BackgroundImage")));
            this.black36.Image = ((System.Drawing.Image)(resources.GetObject("black36.Image")));
            this.black36.Location = new System.Drawing.Point(562, 188);
            this.black36.Name = "black36";
            this.black36.Size = new System.Drawing.Size(78, 60);
            this.black36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black36.TabIndex = 145;
            this.black36.TabStop = false;
            this.black36.Click += new System.EventHandler(this.green36_Click);
            // 
            // black26
            // 
            this.black26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black26.BackgroundImage")));
            this.black26.Image = global::Othello.Properties.Resources.black;
            this.black26.Location = new System.Drawing.Point(562, 104);
            this.black26.Name = "black26";
            this.black26.Size = new System.Drawing.Size(78, 60);
            this.black26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black26.TabIndex = 146;
            this.black26.TabStop = false;
            this.black26.Click += new System.EventHandler(this.green26_Click);
            // 
            // black16
            // 
            this.black16.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black16.Image = global::Othello.Properties.Resources.black;
            this.black16.Location = new System.Drawing.Point(563, 24);
            this.black16.Name = "black16";
            this.black16.Size = new System.Drawing.Size(78, 60);
            this.black16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black16.TabIndex = 147;
            this.black16.TabStop = false;
            this.black16.Click += new System.EventHandler(this.green16_Click);
            // 
            // green87
            // 
            this.green87.Image = ((System.Drawing.Image)(resources.GetObject("green87.Image")));
            this.green87.Location = new System.Drawing.Point(670, 598);
            this.green87.Name = "green87";
            this.green87.Size = new System.Drawing.Size(78, 60);
            this.green87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green87.TabIndex = 156;
            this.green87.TabStop = false;
            this.green87.Click += new System.EventHandler(this.green87_Click);
            // 
            // green77
            // 
            this.green77.Image = ((System.Drawing.Image)(resources.GetObject("green77.Image")));
            this.green77.Location = new System.Drawing.Point(670, 518);
            this.green77.Name = "green77";
            this.green77.Size = new System.Drawing.Size(78, 60);
            this.green77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green77.TabIndex = 157;
            this.green77.TabStop = false;
            this.green77.Click += new System.EventHandler(this.green77_Click);
            // 
            // green67
            // 
            this.green67.Image = ((System.Drawing.Image)(resources.GetObject("green67.Image")));
            this.green67.Location = new System.Drawing.Point(670, 436);
            this.green67.Name = "green67";
            this.green67.Size = new System.Drawing.Size(78, 60);
            this.green67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green67.TabIndex = 158;
            this.green67.TabStop = false;
            this.green67.Click += new System.EventHandler(this.green67_Click);
            // 
            // green57
            // 
            this.green57.Image = ((System.Drawing.Image)(resources.GetObject("green57.Image")));
            this.green57.Location = new System.Drawing.Point(670, 352);
            this.green57.Name = "green57";
            this.green57.Size = new System.Drawing.Size(78, 60);
            this.green57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green57.TabIndex = 159;
            this.green57.TabStop = false;
            this.green57.Click += new System.EventHandler(this.green57_Click);
            // 
            // green47
            // 
            this.green47.Image = ((System.Drawing.Image)(resources.GetObject("green47.Image")));
            this.green47.Location = new System.Drawing.Point(670, 269);
            this.green47.Name = "green47";
            this.green47.Size = new System.Drawing.Size(78, 60);
            this.green47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green47.TabIndex = 160;
            this.green47.TabStop = false;
            this.green47.Click += new System.EventHandler(this.green47_Click);
            // 
            // green37
            // 
            this.green37.Image = ((System.Drawing.Image)(resources.GetObject("green37.Image")));
            this.green37.Location = new System.Drawing.Point(670, 188);
            this.green37.Name = "green37";
            this.green37.Size = new System.Drawing.Size(78, 60);
            this.green37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green37.TabIndex = 161;
            this.green37.TabStop = false;
            this.green37.Click += new System.EventHandler(this.green37_Click);
            // 
            // green27
            // 
            this.green27.Image = ((System.Drawing.Image)(resources.GetObject("green27.Image")));
            this.green27.Location = new System.Drawing.Point(670, 104);
            this.green27.Name = "green27";
            this.green27.Size = new System.Drawing.Size(78, 60);
            this.green27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green27.TabIndex = 162;
            this.green27.TabStop = false;
            this.green27.Click += new System.EventHandler(this.green27_Click);
            // 
            // green17
            // 
            this.green17.Image = ((System.Drawing.Image)(resources.GetObject("green17.Image")));
            this.green17.Location = new System.Drawing.Point(670, 24);
            this.green17.Name = "green17";
            this.green17.Size = new System.Drawing.Size(78, 60);
            this.green17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green17.TabIndex = 163;
            this.green17.TabStop = false;
            this.green17.Click += new System.EventHandler(this.green17_Click);
            // 
            // black87
            // 
            this.black87.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black87.BackgroundImage")));
            this.black87.Image = ((System.Drawing.Image)(resources.GetObject("black87.Image")));
            this.black87.Location = new System.Drawing.Point(670, 598);
            this.black87.Name = "black87";
            this.black87.Size = new System.Drawing.Size(78, 60);
            this.black87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black87.TabIndex = 164;
            this.black87.TabStop = false;
            this.black87.Click += new System.EventHandler(this.green87_Click);
            // 
            // black77
            // 
            this.black77.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black77.BackgroundImage")));
            this.black77.Image = ((System.Drawing.Image)(resources.GetObject("black77.Image")));
            this.black77.Location = new System.Drawing.Point(670, 518);
            this.black77.Name = "black77";
            this.black77.Size = new System.Drawing.Size(78, 60);
            this.black77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black77.TabIndex = 165;
            this.black77.TabStop = false;
            this.black77.Click += new System.EventHandler(this.green77_Click);
            // 
            // black67
            // 
            this.black67.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black67.BackgroundImage")));
            this.black67.Image = ((System.Drawing.Image)(resources.GetObject("black67.Image")));
            this.black67.Location = new System.Drawing.Point(670, 436);
            this.black67.Name = "black67";
            this.black67.Size = new System.Drawing.Size(78, 60);
            this.black67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black67.TabIndex = 166;
            this.black67.TabStop = false;
            this.black67.Click += new System.EventHandler(this.green67_Click);
            // 
            // black57
            // 
            this.black57.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black57.BackgroundImage")));
            this.black57.Image = ((System.Drawing.Image)(resources.GetObject("black57.Image")));
            this.black57.Location = new System.Drawing.Point(670, 352);
            this.black57.Name = "black57";
            this.black57.Size = new System.Drawing.Size(78, 60);
            this.black57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black57.TabIndex = 167;
            this.black57.TabStop = false;
            this.black57.Click += new System.EventHandler(this.green57_Click);
            // 
            // black47
            // 
            this.black47.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black47.BackgroundImage")));
            this.black47.Image = ((System.Drawing.Image)(resources.GetObject("black47.Image")));
            this.black47.Location = new System.Drawing.Point(670, 269);
            this.black47.Name = "black47";
            this.black47.Size = new System.Drawing.Size(78, 60);
            this.black47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black47.TabIndex = 168;
            this.black47.TabStop = false;
            this.black47.Click += new System.EventHandler(this.green47_Click);
            // 
            // black37
            // 
            this.black37.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black37.BackgroundImage")));
            this.black37.Image = ((System.Drawing.Image)(resources.GetObject("black37.Image")));
            this.black37.Location = new System.Drawing.Point(670, 188);
            this.black37.Name = "black37";
            this.black37.Size = new System.Drawing.Size(78, 60);
            this.black37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black37.TabIndex = 169;
            this.black37.TabStop = false;
            this.black37.Click += new System.EventHandler(this.green37_Click);
            // 
            // black27
            // 
            this.black27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black27.BackgroundImage")));
            this.black27.Image = global::Othello.Properties.Resources.black;
            this.black27.Location = new System.Drawing.Point(670, 104);
            this.black27.Name = "black27";
            this.black27.Size = new System.Drawing.Size(78, 60);
            this.black27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black27.TabIndex = 170;
            this.black27.TabStop = false;
            this.black27.Click += new System.EventHandler(this.green27_Click);
            // 
            // black17
            // 
            this.black17.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black17.Image = global::Othello.Properties.Resources.black;
            this.black17.Location = new System.Drawing.Point(670, 24);
            this.black17.Name = "black17";
            this.black17.Size = new System.Drawing.Size(78, 60);
            this.black17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black17.TabIndex = 171;
            this.black17.TabStop = false;
            this.black17.Click += new System.EventHandler(this.green17_Click);
            // 
            // green88
            // 
            this.green88.Image = ((System.Drawing.Image)(resources.GetObject("green88.Image")));
            this.green88.Location = new System.Drawing.Point(775, 598);
            this.green88.Name = "green88";
            this.green88.Size = new System.Drawing.Size(78, 60);
            this.green88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green88.TabIndex = 180;
            this.green88.TabStop = false;
            this.green88.Click += new System.EventHandler(this.green88_Click);
            // 
            // green78
            // 
            this.green78.Image = ((System.Drawing.Image)(resources.GetObject("green78.Image")));
            this.green78.Location = new System.Drawing.Point(775, 518);
            this.green78.Name = "green78";
            this.green78.Size = new System.Drawing.Size(78, 60);
            this.green78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green78.TabIndex = 181;
            this.green78.TabStop = false;
            this.green78.Click += new System.EventHandler(this.green78_Click);
            // 
            // green68
            // 
            this.green68.Image = ((System.Drawing.Image)(resources.GetObject("green68.Image")));
            this.green68.Location = new System.Drawing.Point(775, 436);
            this.green68.Name = "green68";
            this.green68.Size = new System.Drawing.Size(78, 60);
            this.green68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green68.TabIndex = 182;
            this.green68.TabStop = false;
            this.green68.Click += new System.EventHandler(this.green68_Click);
            // 
            // green58
            // 
            this.green58.Image = ((System.Drawing.Image)(resources.GetObject("green58.Image")));
            this.green58.Location = new System.Drawing.Point(775, 352);
            this.green58.Name = "green58";
            this.green58.Size = new System.Drawing.Size(78, 60);
            this.green58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green58.TabIndex = 183;
            this.green58.TabStop = false;
            this.green58.Click += new System.EventHandler(this.green58_Click);
            // 
            // green48
            // 
            this.green48.Image = ((System.Drawing.Image)(resources.GetObject("green48.Image")));
            this.green48.Location = new System.Drawing.Point(775, 269);
            this.green48.Name = "green48";
            this.green48.Size = new System.Drawing.Size(78, 60);
            this.green48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green48.TabIndex = 184;
            this.green48.TabStop = false;
            this.green48.Click += new System.EventHandler(this.green48_Click);
            // 
            // green38
            // 
            this.green38.Image = ((System.Drawing.Image)(resources.GetObject("green38.Image")));
            this.green38.Location = new System.Drawing.Point(775, 188);
            this.green38.Name = "green38";
            this.green38.Size = new System.Drawing.Size(78, 60);
            this.green38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green38.TabIndex = 185;
            this.green38.TabStop = false;
            this.green38.Click += new System.EventHandler(this.green38_Click);
            // 
            // green28
            // 
            this.green28.Image = ((System.Drawing.Image)(resources.GetObject("green28.Image")));
            this.green28.Location = new System.Drawing.Point(775, 104);
            this.green28.Name = "green28";
            this.green28.Size = new System.Drawing.Size(78, 60);
            this.green28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green28.TabIndex = 186;
            this.green28.TabStop = false;
            this.green28.Click += new System.EventHandler(this.green28_Click);
            // 
            // green18
            // 
            this.green18.Image = ((System.Drawing.Image)(resources.GetObject("green18.Image")));
            this.green18.Location = new System.Drawing.Point(775, 24);
            this.green18.Name = "green18";
            this.green18.Size = new System.Drawing.Size(78, 60);
            this.green18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.green18.TabIndex = 187;
            this.green18.TabStop = false;
            this.green18.Click += new System.EventHandler(this.green18_Click);
            // 
            // black88
            // 
            this.black88.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black88.BackgroundImage")));
            this.black88.Image = ((System.Drawing.Image)(resources.GetObject("black88.Image")));
            this.black88.Location = new System.Drawing.Point(777, 598);
            this.black88.Name = "black88";
            this.black88.Size = new System.Drawing.Size(78, 60);
            this.black88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black88.TabIndex = 189;
            this.black88.TabStop = false;
            this.black88.Click += new System.EventHandler(this.green88_Click);
            // 
            // black78
            // 
            this.black78.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black78.BackgroundImage")));
            this.black78.Image = ((System.Drawing.Image)(resources.GetObject("black78.Image")));
            this.black78.Location = new System.Drawing.Point(776, 518);
            this.black78.Name = "black78";
            this.black78.Size = new System.Drawing.Size(78, 60);
            this.black78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black78.TabIndex = 190;
            this.black78.TabStop = false;
            this.black78.Click += new System.EventHandler(this.green78_Click);
            // 
            // black68
            // 
            this.black68.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black68.BackgroundImage")));
            this.black68.Image = ((System.Drawing.Image)(resources.GetObject("black68.Image")));
            this.black68.Location = new System.Drawing.Point(777, 436);
            this.black68.Name = "black68";
            this.black68.Size = new System.Drawing.Size(78, 60);
            this.black68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black68.TabIndex = 191;
            this.black68.TabStop = false;
            this.black68.Click += new System.EventHandler(this.green68_Click);
            // 
            // black58
            // 
            this.black58.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black58.BackgroundImage")));
            this.black58.Image = ((System.Drawing.Image)(resources.GetObject("black58.Image")));
            this.black58.Location = new System.Drawing.Point(775, 352);
            this.black58.Name = "black58";
            this.black58.Size = new System.Drawing.Size(78, 60);
            this.black58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black58.TabIndex = 192;
            this.black58.TabStop = false;
            this.black58.Click += new System.EventHandler(this.green58_Click);
            // 
            // black48
            // 
            this.black48.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black48.BackgroundImage")));
            this.black48.Image = ((System.Drawing.Image)(resources.GetObject("black48.Image")));
            this.black48.Location = new System.Drawing.Point(777, 269);
            this.black48.Name = "black48";
            this.black48.Size = new System.Drawing.Size(78, 60);
            this.black48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black48.TabIndex = 193;
            this.black48.TabStop = false;
            this.black48.Click += new System.EventHandler(this.green48_Click);
            // 
            // black38
            // 
            this.black38.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black38.BackgroundImage")));
            this.black38.Image = ((System.Drawing.Image)(resources.GetObject("black38.Image")));
            this.black38.Location = new System.Drawing.Point(777, 188);
            this.black38.Name = "black38";
            this.black38.Size = new System.Drawing.Size(78, 60);
            this.black38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black38.TabIndex = 194;
            this.black38.TabStop = false;
            this.black38.Click += new System.EventHandler(this.green38_Click);
            // 
            // black28
            // 
            this.black28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("black28.BackgroundImage")));
            this.black28.Image = global::Othello.Properties.Resources.black;
            this.black28.Location = new System.Drawing.Point(776, 104);
            this.black28.Name = "black28";
            this.black28.Size = new System.Drawing.Size(78, 60);
            this.black28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black28.TabIndex = 195;
            this.black28.TabStop = false;
            this.black28.Click += new System.EventHandler(this.green28_Click);
            // 
            // black18
            // 
            this.black18.BackgroundImage = global::Othello.Properties.Resources.Background;
            this.black18.Image = global::Othello.Properties.Resources.black;
            this.black18.Location = new System.Drawing.Point(775, 24);
            this.black18.Name = "black18";
            this.black18.Size = new System.Drawing.Size(78, 60);
            this.black18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.black18.TabIndex = 196;
            this.black18.TabStop = false;
            this.black18.Click += new System.EventHandler(this.green18_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(401, 770);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(75, 38);
            this.reset.TabIndex = 205;
            this.reset.Text = "RESET - dont use";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // helpbutton
            // 
            this.helpbutton.Location = new System.Drawing.Point(31, 841);
            this.helpbutton.Name = "helpbutton";
            this.helpbutton.Size = new System.Drawing.Size(76, 43);
            this.helpbutton.TabIndex = 206;
            this.helpbutton.Text = "Help";
            this.helpbutton.UseVisualStyleBackColor = true;
            this.helpbutton.Click += new System.EventHandler(this.helpbutton_Click);
            // 
            // Aitimer
            // 
            this.Aitimer.Interval = 400;
            this.Aitimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // player1count
            // 
            this.player1count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1count.FormattingEnabled = true;
            this.player1count.ItemHeight = 31;
            this.player1count.Location = new System.Drawing.Point(287, 828);
            this.player1count.Name = "player1count";
            this.player1count.Size = new System.Drawing.Size(120, 35);
            this.player1count.TabIndex = 207;
            // 
            // player2count
            // 
            this.player2count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2count.FormattingEnabled = true;
            this.player2count.ItemHeight = 31;
            this.player2count.Location = new System.Drawing.Point(710, 828);
            this.player2count.Name = "player2count";
            this.player2count.Size = new System.Drawing.Size(120, 35);
            this.player2count.TabIndex = 208;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(177, 832);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 31);
            this.label1.TabIndex = 209;
            this.label1.Text = "Pieces:";
            this.label1.Click += new System.EventHandler(this.helpbutton_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(670, 890);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 210;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Filename
            // 
            this.Filename.Location = new System.Drawing.Point(522, 897);
            this.Filename.Name = "Filename";
            this.Filename.Size = new System.Drawing.Size(100, 20);
            this.Filename.TabIndex = 211;
            this.Filename.Text = "Enter Filename";
            // 
            // load
            // 
            this.load.Location = new System.Drawing.Point(775, 890);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(75, 23);
            this.load.TabIndex = 212;
            this.load.Text = "Load";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.Load_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(148, 818);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 213;
            // 
            // Board
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(884, 925);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.load);
            this.Controls.Add(this.Filename);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.player2count);
            this.Controls.Add(this.player1count);
            this.Controls.Add(this.helpbutton);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.black18);
            this.Controls.Add(this.black28);
            this.Controls.Add(this.black38);
            this.Controls.Add(this.black48);
            this.Controls.Add(this.black58);
            this.Controls.Add(this.black68);
            this.Controls.Add(this.black78);
            this.Controls.Add(this.black88);
            this.Controls.Add(this.green18);
            this.Controls.Add(this.green28);
            this.Controls.Add(this.green38);
            this.Controls.Add(this.green48);
            this.Controls.Add(this.green58);
            this.Controls.Add(this.green68);
            this.Controls.Add(this.green78);
            this.Controls.Add(this.green88);
            this.Controls.Add(this.black17);
            this.Controls.Add(this.black27);
            this.Controls.Add(this.black37);
            this.Controls.Add(this.black47);
            this.Controls.Add(this.black57);
            this.Controls.Add(this.black67);
            this.Controls.Add(this.black77);
            this.Controls.Add(this.black87);
            this.Controls.Add(this.green17);
            this.Controls.Add(this.green27);
            this.Controls.Add(this.green37);
            this.Controls.Add(this.green47);
            this.Controls.Add(this.green57);
            this.Controls.Add(this.green67);
            this.Controls.Add(this.green77);
            this.Controls.Add(this.green87);
            this.Controls.Add(this.black16);
            this.Controls.Add(this.black26);
            this.Controls.Add(this.black36);
            this.Controls.Add(this.black46);
            this.Controls.Add(this.black56);
            this.Controls.Add(this.black66);
            this.Controls.Add(this.black76);
            this.Controls.Add(this.black86);
            this.Controls.Add(this.green16);
            this.Controls.Add(this.green26);
            this.Controls.Add(this.green36);
            this.Controls.Add(this.green46);
            this.Controls.Add(this.green56);
            this.Controls.Add(this.green66);
            this.Controls.Add(this.green76);
            this.Controls.Add(this.green86);
            this.Controls.Add(this.black15);
            this.Controls.Add(this.black25);
            this.Controls.Add(this.black35);
            this.Controls.Add(this.black45);
            this.Controls.Add(this.black55);
            this.Controls.Add(this.black65);
            this.Controls.Add(this.black75);
            this.Controls.Add(this.black85);
            this.Controls.Add(this.green15);
            this.Controls.Add(this.green25);
            this.Controls.Add(this.green35);
            this.Controls.Add(this.green45);
            this.Controls.Add(this.green55);
            this.Controls.Add(this.green65);
            this.Controls.Add(this.green75);
            this.Controls.Add(this.green85);
            this.Controls.Add(this.black14);
            this.Controls.Add(this.black24);
            this.Controls.Add(this.black34);
            this.Controls.Add(this.black44);
            this.Controls.Add(this.black54);
            this.Controls.Add(this.black64);
            this.Controls.Add(this.black74);
            this.Controls.Add(this.black84);
            this.Controls.Add(this.green14);
            this.Controls.Add(this.green24);
            this.Controls.Add(this.green34);
            this.Controls.Add(this.green44);
            this.Controls.Add(this.green54);
            this.Controls.Add(this.green64);
            this.Controls.Add(this.green74);
            this.Controls.Add(this.green84);
            this.Controls.Add(this.black13);
            this.Controls.Add(this.black23);
            this.Controls.Add(this.black33);
            this.Controls.Add(this.black43);
            this.Controls.Add(this.black53);
            this.Controls.Add(this.black63);
            this.Controls.Add(this.black73);
            this.Controls.Add(this.black83);
            this.Controls.Add(this.green13);
            this.Controls.Add(this.green23);
            this.Controls.Add(this.green33);
            this.Controls.Add(this.green43);
            this.Controls.Add(this.green53);
            this.Controls.Add(this.green63);
            this.Controls.Add(this.green73);
            this.Controls.Add(this.green83);
            this.Controls.Add(this.black12);
            this.Controls.Add(this.black22);
            this.Controls.Add(this.black32);
            this.Controls.Add(this.black42);
            this.Controls.Add(this.black52);
            this.Controls.Add(this.black62);
            this.Controls.Add(this.black72);
            this.Controls.Add(this.black82);
            this.Controls.Add(this.green12);
            this.Controls.Add(this.green22);
            this.Controls.Add(this.green32);
            this.Controls.Add(this.green42);
            this.Controls.Add(this.green52);
            this.Controls.Add(this.green62);
            this.Controls.Add(this.green72);
            this.Controls.Add(this.green82);
            this.Controls.Add(this.black51);
            this.Controls.Add(this.black61);
            this.Controls.Add(this.black71);
            this.Controls.Add(this.black81);
            this.Controls.Add(this.green51);
            this.Controls.Add(this.green61);
            this.Controls.Add(this.green71);
            this.Controls.Add(this.green81);
            this.Controls.Add(this.end);
            this.Controls.Add(this.black41);
            this.Controls.Add(this.black21);
            this.Controls.Add(this.black31);
            this.Controls.Add(this.green21);
            this.Controls.Add(this.green31);
            this.Controls.Add(this.green41);
            this.Controls.Add(this.black11);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.player2select);
            this.Controls.Add(this.player1select);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.green11);
            this.Controls.Add(this.background);
            this.Name = "Board";
            this.Text = "Othello";
            ((System.ComponentModel.ISupportInitialize)(this.player1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1select)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2select)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.black18)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox player1;
        private System.Windows.Forms.PictureBox player2;
        private System.Windows.Forms.PictureBox player1select;
        private System.Windows.Forms.PictureBox player2select;
        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox green11;
        private System.Windows.Forms.PictureBox black11;
        private System.Windows.Forms.PictureBox green41;
        private System.Windows.Forms.PictureBox green31;
        private System.Windows.Forms.PictureBox green21;
        private System.Windows.Forms.PictureBox black31;
        private System.Windows.Forms.PictureBox black21;
        private System.Windows.Forms.PictureBox black41;
        private System.Windows.Forms.Button end;
        private System.Windows.Forms.PictureBox green81;
        private System.Windows.Forms.PictureBox green71;
        private System.Windows.Forms.PictureBox green61;
        private System.Windows.Forms.PictureBox green51;
        private System.Windows.Forms.PictureBox black81;
        private System.Windows.Forms.PictureBox black71;
        private System.Windows.Forms.PictureBox black61;
        private System.Windows.Forms.PictureBox black51;
        private System.Windows.Forms.PictureBox green82;
        private System.Windows.Forms.PictureBox green72;
        private System.Windows.Forms.PictureBox green62;
        private System.Windows.Forms.PictureBox green52;
        private System.Windows.Forms.PictureBox green42;
        private System.Windows.Forms.PictureBox green32;
        private System.Windows.Forms.PictureBox green22;
        private System.Windows.Forms.PictureBox green12;
        private System.Windows.Forms.PictureBox black82;
        private System.Windows.Forms.PictureBox black72;
        private System.Windows.Forms.PictureBox black62;
        private System.Windows.Forms.PictureBox black52;
        private System.Windows.Forms.PictureBox black42;
        private System.Windows.Forms.PictureBox black32;
        private System.Windows.Forms.PictureBox black22;
        private System.Windows.Forms.PictureBox black12;
        private System.Windows.Forms.PictureBox green83;
        private System.Windows.Forms.PictureBox green73;
        private System.Windows.Forms.PictureBox green63;
        private System.Windows.Forms.PictureBox green53;
        private System.Windows.Forms.PictureBox green43;
        private System.Windows.Forms.PictureBox green33;
        private System.Windows.Forms.PictureBox green23;
        private System.Windows.Forms.PictureBox green13;
        private System.Windows.Forms.PictureBox black83;
        private System.Windows.Forms.PictureBox black73;
        private System.Windows.Forms.PictureBox black63;
        private System.Windows.Forms.PictureBox black53;
        private System.Windows.Forms.PictureBox black43;
        private System.Windows.Forms.PictureBox black33;
        private System.Windows.Forms.PictureBox black23;
        private System.Windows.Forms.PictureBox black13;
        private System.Windows.Forms.PictureBox green84;
        private System.Windows.Forms.PictureBox green74;
        private System.Windows.Forms.PictureBox green64;
        private System.Windows.Forms.PictureBox green54;
        private System.Windows.Forms.PictureBox green44;
        private System.Windows.Forms.PictureBox green34;
        private System.Windows.Forms.PictureBox green24;
        private System.Windows.Forms.PictureBox green14;
        private System.Windows.Forms.PictureBox black84;
        private System.Windows.Forms.PictureBox black74;
        private System.Windows.Forms.PictureBox black64;
        private System.Windows.Forms.PictureBox black54;
        private System.Windows.Forms.PictureBox black44;
        private System.Windows.Forms.PictureBox black34;
        private System.Windows.Forms.PictureBox black24;
        private System.Windows.Forms.PictureBox black14;
        private System.Windows.Forms.PictureBox green85;
        private System.Windows.Forms.PictureBox green75;
        private System.Windows.Forms.PictureBox green65;
        private System.Windows.Forms.PictureBox green55;
        private System.Windows.Forms.PictureBox green45;
        private System.Windows.Forms.PictureBox green35;
        private System.Windows.Forms.PictureBox green25;
        private System.Windows.Forms.PictureBox green15;
        private System.Windows.Forms.PictureBox black85;
        private System.Windows.Forms.PictureBox black75;
        private System.Windows.Forms.PictureBox black65;
        private System.Windows.Forms.PictureBox black55;
        private System.Windows.Forms.PictureBox black45;
        private System.Windows.Forms.PictureBox black35;
        private System.Windows.Forms.PictureBox black25;
        private System.Windows.Forms.PictureBox black15;
        private System.Windows.Forms.PictureBox green86;
        private System.Windows.Forms.PictureBox green76;
        private System.Windows.Forms.PictureBox green66;
        private System.Windows.Forms.PictureBox green56;
        private System.Windows.Forms.PictureBox green46;
        private System.Windows.Forms.PictureBox green36;
        private System.Windows.Forms.PictureBox green26;
        private System.Windows.Forms.PictureBox green16;
        private System.Windows.Forms.PictureBox black86;
        private System.Windows.Forms.PictureBox black76;
        private System.Windows.Forms.PictureBox black66;
        private System.Windows.Forms.PictureBox black56;
        private System.Windows.Forms.PictureBox black46;
        private System.Windows.Forms.PictureBox black36;
        private System.Windows.Forms.PictureBox black26;
        private System.Windows.Forms.PictureBox black16;
        private System.Windows.Forms.PictureBox green87;
        private System.Windows.Forms.PictureBox green77;
        private System.Windows.Forms.PictureBox green67;
        private System.Windows.Forms.PictureBox green57;
        private System.Windows.Forms.PictureBox green47;
        private System.Windows.Forms.PictureBox green37;
        private System.Windows.Forms.PictureBox green27;
        private System.Windows.Forms.PictureBox green17;
        private System.Windows.Forms.PictureBox black87;
        private System.Windows.Forms.PictureBox black77;
        private System.Windows.Forms.PictureBox black67;
        private System.Windows.Forms.PictureBox black57;
        private System.Windows.Forms.PictureBox black47;
        private System.Windows.Forms.PictureBox black37;
        private System.Windows.Forms.PictureBox black27;
        private System.Windows.Forms.PictureBox black17;
        private System.Windows.Forms.PictureBox green88;
        private System.Windows.Forms.PictureBox green78;
        private System.Windows.Forms.PictureBox green68;
        private System.Windows.Forms.PictureBox green58;
        private System.Windows.Forms.PictureBox green48;
        private System.Windows.Forms.PictureBox green38;
        private System.Windows.Forms.PictureBox green28;
        private System.Windows.Forms.PictureBox green18;
        private System.Windows.Forms.PictureBox black88;
        private System.Windows.Forms.PictureBox black78;
        private System.Windows.Forms.PictureBox black68;
        private System.Windows.Forms.PictureBox black58;
        private System.Windows.Forms.PictureBox black48;
        private System.Windows.Forms.PictureBox black38;
        private System.Windows.Forms.PictureBox black28;
        private System.Windows.Forms.PictureBox black18;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button helpbutton;
        private System.Windows.Forms.Timer Aitimer;
        private System.Windows.Forms.ListBox player1count;
        private System.Windows.Forms.ListBox player2count;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox Filename;
        private System.Windows.Forms.Button load;
        private System.Windows.Forms.ListBox listBox1;
    }
}

