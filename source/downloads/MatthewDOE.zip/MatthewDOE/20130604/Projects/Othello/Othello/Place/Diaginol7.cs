﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Place
    {
        public void diaginol7(int player, int place, int coloumn)
        {
            if (player == 1)
            {
                if ((place + 49 < (coloumn + 7) * 8) && (place + 49 < 64))
                {
                    if ((checka[place + 49] == 1) && (checka[place + 42] == 2) && (checka[place + 35] == 2)
                        && (checka[place + 28] == 2) && (checka[place + 21] == 2) && (checka[place + 14] == 2) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 6;
                    }
                }

                if ((place + 42 < (coloumn + 6) * 8) && (place + 42 < 64))
                {
                    if ((checka[place + 42] == 1) && (checka[place + 35] == 2) && (checka[place + 28] == 2)
                                && (checka[place + 21] == 2) && (checka[place + 14] == 2) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 5;
                    }
                }

                if ((place + 35 < (coloumn + 5) * 8) && (place + 35 < 64))
                {
                    if ((checka[place + 35] == 1) && (checka[place + 28] == 2)
                       && (checka[place + 21] == 2) && (checka[place + 14] == 2) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 4;
                    }
                }

                if ((place + 28 < (coloumn + 4) * 8) && (place + 28 < 64))
                {
                    if ((checka[place + 28] == 1) && (checka[place + 21] == 2) && (checka[place + 14] == 2) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 3;
                    }
                }

                if ((place + 21 < (coloumn + 3) * 8) && (place + 21 < 64))
                {
                    if ((checka[place + 21] == 1) && (checka[place + 14] == 2) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 2;
                    }
                }

                if ((place + 14 < (coloumn + 2) * 8) && (place + 14 < 64))
                {
                    if ((checka[place + 14] == 1) && (checka[place + 7] == 2))
                    {
                        tochange[8] = 1;
                    }
                }



                if ((place - 49 > (coloumn - 9) * 8) && (place - 49 > 0))
                {
                    if ((checka[place - 49] == 1) && (checka[place - 42] == 2) && (checka[place - 35] == 2)
                        && (checka[place - 28] == 2) && (checka[place - 21] == 2) && (checka[place - 14] == 2) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 6;
                    }
                }

                if ((place - 42 > (coloumn - 8) * 8) && (place - 42 > 0))
                {
                    if ((checka[place - 42] == 1) && (checka[place - 35] == 2) && (checka[place - 28] == 2)
                                && (checka[place - 21] == 2) && (checka[place - 14] == 2) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 5;
                    }
                }

                if ((place - 35 > (coloumn - 7) * 8) && (place - 35 > 0))
                {
                    if ((checka[place - 35] == 1) && (checka[place - 28] == 2)
                       && (checka[place - 21] == 2) && (checka[place - 14] == 2) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 4;
                    }
                }

                if ((place - 28 > (coloumn - 6) * 8) && (place - 28 > 0))
                {
                    if ((checka[place - 28] == 1) && (checka[place - 21] == 2) && (checka[place - 14] == 2) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 3;
                    }
                }

                if ((place - 21 > (coloumn - 5) * 8) && (place - 21 > 0))
                {
                    if ((checka[place - 21] == 1) && (checka[place - 14] == 2) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 2;
                    }
                }

                if ((place - 14 > (coloumn - 4) * 8) && (place - 14 > 0))
                {
                    if ((checka[place - 14] == 1) && (checka[place - 7] == 2))
                    {
                        tochange[9] = 1;
                    }
                }
            }
            else
            {
                if ((place + 49 < (coloumn + 7) * 8) && (place + 49 < 64))
                {
                    if ((checka[place + 49] == 2) && (checka[place + 42] == 1) && (checka[place + 35] == 1)
                        && (checka[place + 28] == 1) && (checka[place + 21] == 1) && (checka[place + 14] == 1) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 6;
                    }
                }

                if ((place + 42 < (coloumn + 6) * 8) && (place + 42 < 64))
                {
                    if ((checka[place + 42] == 2) && (checka[place + 35] == 1) && (checka[place + 28] == 1)
                                && (checka[place + 21] == 1) && (checka[place + 14] == 1) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 5;
                    }
                }

                if ((place + 35 < (coloumn + 5) * 8) && (place + 35 < 64))
                {
                    if ((checka[place + 35] == 2) && (checka[place + 28] == 1)
                       && (checka[place + 21] == 1) && (checka[place + 14] == 1) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 4;
                    }
                }

                if ((place + 28 < (coloumn + 4) * 8) && (place + 28 < 64))
                {
                    if ((checka[place + 28] == 2) && (checka[place + 21] == 1) && (checka[place + 14] == 1) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 3;
                    }
                }

                if ((place + 21 < (coloumn + 3) * 8) && (place + 21 < 64))
                {
                    if ((checka[place + 21] == 2) && (checka[place + 14] == 1) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 2;
                    }
                }

                if ((place + 14 < (coloumn + 2) * 8) && (place + 14 < 64))
                {
                    if ((checka[place + 14] == 2) && (checka[place + 7] == 1))
                    {
                        tochange[8] = 1;
                    }
                }



                if ((place - 49 > (coloumn - 9) * 8) && (place - 49 > 0))
                {
                    if ((checka[place - 49] == 2) && (checka[place - 42] == 1) && (checka[place - 35] == 1)
                        && (checka[place - 28] == 1) && (checka[place - 21] == 1) && (checka[place - 14] == 1) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 6;
                    }
                }

                if ((place - 42 > (coloumn - 9) * 8) && (place - 42 > 0))
                {
                    if ((checka[place - 42] == 2) && (checka[place - 35] == 1) && (checka[place - 28] == 1)
                                && (checka[place - 21] == 1) && (checka[place - 14] == 1) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 5;
                    }
                }

                if ((place - 35 > (coloumn - 9) * 8) && (place - 35 > 0))
                {
                    if ((checka[place - 35] == 2) && (checka[place - 28] == 1)
                       && (checka[place - 21] == 1) && (checka[place - 14] == 1) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 4;
                    }
                }

                if ((place - 28 > (coloumn - 9) * 8) && (place - 28 > 0))
                {
                    if ((checka[place - 28] == 2) && (checka[place - 21] == 1) && (checka[place - 14] == 1) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 3;
                    }
                }

                if ((place - 21 > (coloumn - 9) * 8) && (place - 21 > 0))
                {
                    if ((checka[place - 21] == 2) && (checka[place - 14] == 1) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 2;
                    }
                }

                if ((place - 14 > (coloumn - 9) * 8) && (place - 14 > 0))
                {
                    if ((checka[place - 14] == 2) && (checka[place - 7] == 1))
                    {
                        tochange[9] = 1;
                    }
                }
            }
        }
    }
}