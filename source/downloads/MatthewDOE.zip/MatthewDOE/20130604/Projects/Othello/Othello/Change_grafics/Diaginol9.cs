﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        private void Change_diaginol9(int place)
        {
            if (access.tochange[0] == 2)
            {
                if (access.tochange[6] == 1)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                }
                if (access.tochange[6] == 2)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 2;
                }
                if (access.tochange[6] == 3)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 2;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 2;
                }
                if (access.tochange[6] == 4)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 2;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 2;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 2;
                }
                if (access.tochange[6] == 5)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 2;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 2;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 2;
                    turnover(place + 45);
                    Ai.access.checka[place + 45] = 2;
                }
                if (access.tochange[6] == 6)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 2;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 2;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 2;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 2;
                    turnover(place + 45);
                    Ai.access.checka[place + 45] = 2;
                    turnover(place + 54);
                    Ai.access.checka[place + 54] = 2;
                }

                if (access.tochange[7] == 1)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                }
                if (access.tochange[7] == 2)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 2;
                }
                if (access.tochange[7] == 3)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 2;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 2;
                }
                if (access.tochange[7] == 4)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 2;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 2;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 2;
                }
                if (access.tochange[7] == 5)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 2;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 2;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 2;
                    turnover(place - 45);
                    Ai.access.checka[place - 45] = 2;
                }
                if (access.tochange[7] == 6)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 2;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 2;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 2;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 2;
                    turnover(place - 45);
                    Ai.access.checka[place - 45] = 2;
                    turnover(place - 54);
                    Ai.access.checka[place - 54] = 2;
                }
            }
            else
            {
                if (access.tochange[6] == 1)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                }
                if (access.tochange[6] == 2)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 1;
                }
                if (access.tochange[6] == 3)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 1;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 1;
                }
                if (access.tochange[6] == 4)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 1;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 1;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 1;
                }
                if (access.tochange[6] == 5)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 1;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 1;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 1;
                    turnover(place + 45);
                    Ai.access.checka[place + 45] = 1;
                }
                if (access.tochange[6] == 6)
                {
                    turnover(place + 9);
                    Ai.access.checka[place + 9] = 1;
                    turnover(place + 18);
                    Ai.access.checka[place + 18] = 1;
                    turnover(place + 27);
                    Ai.access.checka[place + 27] = 1;
                    turnover(place + 36);
                    Ai.access.checka[place + 36] = 1;
                    turnover(place + 45);
                    Ai.access.checka[place + 45] = 1;
                    turnover(place + 54);
                    Ai.access.checka[place + 54] = 1;
                }

                if (access.tochange[7] == 1)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                }
                if (access.tochange[7] == 2)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 1;
                }
                if (access.tochange[7] == 3)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 1;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 1;
                }
                if (access.tochange[7] == 4)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 1;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 1;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 1;
                }
                if (access.tochange[7] == 5)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 1;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 1;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 1;
                    turnover(place - 45);
                    Ai.access.checka[place - 45] = 1;
                }
                if (access.tochange[7] == 6)
                {
                    turnover(place - 9);
                    Ai.access.checka[place - 9] = 1;
                    turnover(place - 18);
                    Ai.access.checka[place - 18] = 1;
                    turnover(place - 27);
                    Ai.access.checka[place - 27] = 1;
                    turnover(place - 36);
                    Ai.access.checka[place - 36] = 1;
                    turnover(place - 45);
                    Ai.access.checka[place - 45] = 1;
                    turnover(place - 54);
                    Ai.access.checka[place - 54] = 1;
                }
            }

        }
    }
}