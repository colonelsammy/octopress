﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Othello
{
    public partial class Board
    {
        public void picture()
        {
            for (int x = 0; x < 64; x = x + 1)
            {
                black.Add(new Piece());
                black[x].piece_colour = 1;
            }

            black[0].Picture = black11;
            black[1].Picture = black21;
            black[2].Picture = black31;
            black[3].Picture = black41;
            black[4].Picture = black51;
            black[5].Picture = black61;
            black[6].Picture = black71;
            black[7].Picture = black81;

            black[8].Picture = black12;
            black[9].Picture = black22;
            black[10].Picture = black32;
            black[11].Picture = black42;
            black[12].Picture = black52;
            black[13].Picture = black62;
            black[14].Picture = black72;
            black[15].Picture = black82;

            black[16].Picture = black13;
            black[17].Picture = black23;
            black[18].Picture = black33;
            black[19].Picture = black43;
            black[20].Picture = black53;
            black[21].Picture = black63;
            black[22].Picture = black73;
            black[23].Picture = black83;

            black[24].Picture = black14;
            black[25].Picture = black24;
            black[26].Picture = black34;
            black[27].Picture = black44;
            black[28].Picture = black54;
            black[29].Picture = black64;
            black[30].Picture = black74;
            black[31].Picture = black84;

            black[32].Picture = black15;
            black[33].Picture = black25;
            black[34].Picture = black35;
            black[35].Picture = black45;
            black[36].Picture = black55;
            black[37].Picture = black65;
            black[38].Picture = black75;
            black[39].Picture = black85;

            black[40].Picture = black16;
            black[41].Picture = black26;
            black[42].Picture = black36;
            black[43].Picture = black46;
            black[44].Picture = black56;
            black[45].Picture = black66;
            black[46].Picture = black76;
            black[47].Picture = black86;

            black[48].Picture = black17;
            black[49].Picture = black27;
            black[50].Picture = black37;
            black[51].Picture = black47;
            black[52].Picture = black57;
            black[53].Picture = black67;
            black[54].Picture = black77;
            black[55].Picture = black87;

            black[56].Picture = black18;
            black[57].Picture = black28;
            black[58].Picture = black38;
            black[59].Picture = black48;
            black[60].Picture = black58;
            black[61].Picture = black68;
            black[62].Picture = black78;
            black[63].Picture = black88;

            for (int x = 0; x < 64; x = x + 1)
            {
                black[x].Picture.Image = Othello.Properties.Resources.black;
                black[x].Picture.Hide();
            }
            black[27].Picture.Image = Othello.Properties.Resources.white;
            black[27].Picture.Show();
            black[28].Picture.Show();
            black[36].Picture.Image = Othello.Properties.Resources.white;
            black[36].Picture.Show();
            black[35].Picture.Show();
        }
    }
}